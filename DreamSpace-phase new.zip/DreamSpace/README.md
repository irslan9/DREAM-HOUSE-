# DreamSpace - Interior Material Calculator

Native Android (Kotlin, Jetpack Compose, Material 3). Offline, no permissions.

## Build status
- Phase 1: project skeleton, dashboard (14 cards), theme, navigation - done
- Phase 2: measurement engine (ft, in, ft+in, mm, cm, m; BigDecimal) + Unit Converter + unit tests - done
- Phase 3: tile calculators, custom panel layout estimator, saved panel sizes - done
- Phase 4: marble/granite, staircase, false ceiling, paint, wallpaper, cost estimator - done
- Phase 5: Room, DataStore, projects, PDF export
- Phase 6: full test suite and release polish

Saved Projects and PDF Reports (phase 5) still open a status screen.

## Open and run
1. Install Android Studio (Koala 2024.1 or newer) with JDK 17 (bundled).
2. File > Open > select the DreamSpace folder. Wait for Gradle sync (needs internet once).
3. Run the unit tests: right-click app/src/test > Run Tests.
4. Plug in a phone (USB debugging on) or start an emulator, press Run.

## Debug APK (for testing)
Build > Build Bundle(s) / APK(s) > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk

## Signed release APK
1. Build > Generate Signed Bundle / APK > APK > Create new keystore. Save the .jks somewhere safe and back it up. If you lose it you cannot update the app.
2. Or by file: copy keystore.properties.example to keystore.properties, fill in your values, then run
   `gradlew assembleRelease` (Windows) or `./gradlew assembleRelease` (Mac/Linux).
   If the wrapper scripts are missing, run `gradle wrapper` once or use the Android Studio menu.
3. Output: app/build/outputs/apk/release/app-release.apk

## Install on a phone
1. Copy the APK to the phone (USB, Drive, WhatsApp to yourself).
2. Open it from Files. Allow "Install unknown apps" for that app when asked.
3. Tap Install, then Open.
Or with USB debugging: `adb install -r app-debug.apk`

## Build without Android Studio (GitHub Actions)
Push this folder to a GitHub repository. The workflow in .github/workflows/build-apk.yml
runs the unit tests and builds app-debug.apk automatically. Download it from
Actions > latest run > Artifacts > DreamSpace-debug-apk.
