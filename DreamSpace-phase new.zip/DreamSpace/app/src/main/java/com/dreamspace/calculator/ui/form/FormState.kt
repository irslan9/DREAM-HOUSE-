package com.dreamspace.calculator.ui.form

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.MeasurementParser
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal

class RowList {
    val ids = mutableStateListOf<Int>()
    private var next = 0
    fun add(): Int { val id = next++; ids.add(id); return id }
    fun remove(id: Int) { ids.remove(id) }
}

/** All text, units and errors of one calculator form, keyed by field name. */
class FormState(val defaultUnit: LengthUnit = LengthUnit.FEET_INCHES) {
    val values = mutableStateMapOf<String, String>()
    val units = mutableStateMapOf<String, LengthUnit>()
    val flags = mutableStateMapOf<String, Boolean>()
    val errors = mutableStateMapOf<String, String>()
    var onEdited: () -> Unit = {}
    private val lists = HashMap<String, RowList>()

    fun list(name: String, initial: Int = 1): RowList =
        lists.getOrPut(name) { RowList().also { l -> repeat(initial) { l.add() } } }

    fun getText(key: String): String = values[key] ?: ""
    fun unit(key: String): LengthUnit = units[key] ?: defaultUnit
    fun flag(key: String): Boolean = flags[key] ?: false
    fun setText(key: String, v: String) { values[key] = v; errors.remove(key); onEdited() }
    fun setUnit(key: String, u: LengthUnit) { units[key] = u; errors.remove(key); onEdited() }
    fun setFlag(key: String, v: Boolean) { flags[key] = v; onEdited() }
}

/** Reads and validates fields. Never throws; failures are stored as per-field errors. */
class FormReader(private val f: FormState) {
    var failed = false
        private set

    init { f.errors.clear() }

    fun error(key: String, msg: String) { f.errors[key] = msg; failed = true }

    fun length(key: String, label: String, allowZero: Boolean = false): Length? =
        when (val r = MeasurementParser.parse(f.getText(key), f.unit(key), label, allowZero)) {
            is Parsed.Ok -> r.value
            is Parsed.Err -> { error(key, r.message); null }
        }

    fun optLength(key: String, label: String): Length? =
        if (f.getText(key).isBlank()) null else length(key, label, true)

    fun decimal(key: String, label: String, allowZero: Boolean = false, max: BigDecimal = BigDecimal("1000000000")): BigDecimal? =
        when (val r = MeasurementParser.parseDecimal(f.getText(key), label, allowZero, max)) {
            is Parsed.Ok -> r.value
            is Parsed.Err -> { error(key, r.message); null }
        }

    fun optDecimal(key: String, label: String): BigDecimal? =
        if (f.getText(key).isBlank()) null else decimal(key, label, true)

    fun percent(key: String, label: String): BigDecimal? = decimal(key, label, true, BigDecimal(100))

    fun count(key: String, label: String, max: Long = 100000L): Long? {
        val d = decimal(key, label, false, BigDecimal(max)) ?: return null
        if (d.stripTrailingZeros().scale() > 0) { error(key, "$label must be a whole number."); return null }
        return d.toLong()
    }

    fun optCount(key: String, label: String): Long? =
        if (f.getText(key).isBlank()) null else count(key, label)

    /** Reads rows of two lengths named "<prefix><id>.a" and "<prefix><id>.b". */
    fun pairs(list: RowList, prefix: String, labelA: String, labelB: String): List<Pair<Length, Length>> {
        val out = ArrayList<Pair<Length, Length>>()
        for (id in list.ids) {
            val a = length("$prefix$id.a", labelA)
            val b = length("$prefix$id.b", labelB)
            if (a != null && b != null) out.add(a to b)
        }
        return out
    }
}
