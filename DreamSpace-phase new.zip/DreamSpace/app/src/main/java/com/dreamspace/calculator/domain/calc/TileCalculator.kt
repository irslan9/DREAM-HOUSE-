package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal

data class TileSurface(val name: String, val width: Length, val height: Length)

data class TileInput(
    val surfaces: List<TileSurface>,
    val openings: List<Dim>,
    val tile: Dim,
    val wastagePercent: BigDecimal,
    val piecesPerBox: Long?,
    val basis: PriceBasis,
    val price: BigDecimal?,
)

data class TileResult(
    val gross: Area,
    val deduction: Area,
    val net: Area,
    val tileArea: Area,
    val theoreticalExact: BigDecimal,
    val theoretical: Long,
    val practical: Long,
    val wastageTiles: Long,
    val wastagePercent: BigDecimal,
    val boxes: Long?,
    val purchasedTiles: Long,
    val cost: BigDecimal?,
)

object TileCalculator {
    fun calculate(i: TileInput): Parsed<TileResult> {
        if (i.surfaces.isEmpty()) return Parsed.Err("Add at least one room or wall.")
        val gross = i.surfaces.fold(Area.ZERO) { acc, s -> acc + Area.of(s.width, s.height) }
        val deduction = i.openings.fold(Area.ZERO) { acc, o -> acc + Area(o.area) }
        if (deduction >= gross) return Parsed.Err("Doors and windows cover the whole wall area. Check their sizes.")
        val net = gross - deduction
        val tileArea = Area(i.tile.area)
        val exact = net.sqMm.divMc(tileArea.sqMm)
        val theoretical = exact.ceilLong()
        val practical = exact.withAllowance(i.wastagePercent).ceilLong()
        val boxes = i.piecesPerBox?.let { per -> (practical.toBd().divMc(per.toBd())).ceilLong() }
        val purchased = if (boxes != null && i.piecesPerBox != null) boxes * i.piecesPerBox else practical
        if (i.basis == PriceBasis.PER_BOX && i.price != null && boxes == null) {
            return Parsed.Err("Enter pieces per box to price by box.")
        }
        val cost = i.price?.let { Pricing.pieceCost(i.basis, it, purchased, tileArea, boxes) }
        return Parsed.Ok(
            TileResult(
                gross, deduction, net, tileArea, exact, theoretical, practical,
                practical - theoretical, i.wastagePercent, boxes, purchased, cost,
            ),
        )
    }
}
