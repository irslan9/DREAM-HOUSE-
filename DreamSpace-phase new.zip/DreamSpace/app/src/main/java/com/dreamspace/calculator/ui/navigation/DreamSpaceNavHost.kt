package com.dreamspace.calculator.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.dreamspace.calculator.ui.components.PendingScreen
import com.dreamspace.calculator.ui.converter.ConverterScreen
import com.dreamspace.calculator.ui.dashboard.DashboardScreen
import com.dreamspace.calculator.ui.home.CeilingScreen
import com.dreamspace.calculator.ui.home.CostScreen
import com.dreamspace.calculator.ui.home.PaintScreen
import com.dreamspace.calculator.ui.home.StairScreen
import com.dreamspace.calculator.ui.home.WallpaperScreen
import com.dreamspace.calculator.ui.panel.PanelScreen
import com.dreamspace.calculator.ui.panel.PanelType
import com.dreamspace.calculator.ui.tile.TileMode
import com.dreamspace.calculator.ui.tile.TileScreen

private const val DASHBOARD = "dashboard"

@Composable
fun DreamSpaceNavHost() {
    val nav = rememberNavController()
    val back: () -> Unit = { nav.popBackStack() }
    NavHost(
        navController = nav,
        startDestination = DASHBOARD,
        enterTransition = { fadeIn(tween(240)) + slideInHorizontally(tween(240)) { it / 14 } },
        exitTransition = { fadeOut(tween(160)) },
        popEnterTransition = { fadeIn(tween(240)) },
        popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(240)) { it / 14 } },
    ) {
        composable(DASHBOARD) { DashboardScreen(onOpen = { nav.navigate(it.route) }) }
        composable(Destination.UnitConverter.route) { ConverterScreen(onBack = back) }
        composable(Destination.FloorTile.route) { TileScreen(TileMode.FLOOR, back) }
        composable(Destination.WallTile.route) { TileScreen(TileMode.WALL, back) }
        composable(Destination.PvcPanel.route) { PanelScreen(Destination.PvcPanel.title, PanelType.PVC, back) }
        composable(Destination.WpcPanel.route) { PanelScreen(Destination.WpcPanel.title, PanelType.WPC, back) }
        composable(Destination.FlutedPanel.route) { PanelScreen(Destination.FlutedPanel.title, PanelType.FLUTED, back) }
        composable(Destination.MarbleGranite.route) { PanelScreen(Destination.MarbleGranite.title, PanelType.MARBLE_GRANITE, back) }
        composable(Destination.Staircase.route) { StairScreen(back) }
        composable(Destination.FalseCeiling.route) { CeilingScreen(back) }
        composable(Destination.Paint.route) { PaintScreen(back) }
        composable(Destination.Wallpaper.route) { WallpaperScreen(back) }
        composable(Destination.CostEstimator.route) { CostScreen(back) }
        Destination.entries.filter { it.phase != null }.forEach { d ->
            composable(d.route) { PendingScreen(d, onBack = back) }
        }
    }
}
