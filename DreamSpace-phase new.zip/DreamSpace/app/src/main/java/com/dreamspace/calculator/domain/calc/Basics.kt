package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.Precision.MC
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/** A width x height in millimeters. */
data class Dim(val w: BigDecimal, val h: BigDecimal) {
    val area: BigDecimal get() = w.multiply(h)
    val areaValue: Area get() = Area(area)
}

fun Long.toBd(): BigDecimal = BigDecimal.valueOf(this)
fun BigDecimal.ceilLong(): Long = setScale(0, RoundingMode.CEILING).longValueExact()
fun BigDecimal.floorLong(): Long = setScale(0, RoundingMode.FLOOR).longValueExact()
fun BigDecimal.divMc(o: BigDecimal): BigDecimal = divide(o, MC)

/** value x (1 + percent/100), unrounded. */
fun BigDecimal.withAllowance(percent: BigDecimal): BigDecimal =
    multiply(BigDecimal.ONE.add(percent.divide(BigDecimal(100), MC)))

fun BigDecimal.plain(): String = if (signum() == 0) "0" else stripTrailingZeros().toPlainString()

fun BigDecimal.pkr(): String {
    val f = DecimalFormat("#,##0", DecimalFormatSymbols(Locale.US))
    return "PKR " + f.format(setScale(0, RoundingMode.HALF_UP))
}
