package com.dreamspace.calculator.ui.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dreamspace.calculator.ui.navigation.Destination

/** Honest status screen for calculators that arrive in a later build phase. */
@Composable
fun PendingScreen(destination: Destination, onBack: () -> Unit) {
    ScreenScaffold(title = destination.title, onBack = onBack) {
        Spacer(Modifier.height(24.dp))
        Icon(destination.icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(48.dp))
        Text("Arrives in build phase ${destination.phase}", style = MaterialTheme.typography.headlineSmall)
        Text(destination.blurb, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
