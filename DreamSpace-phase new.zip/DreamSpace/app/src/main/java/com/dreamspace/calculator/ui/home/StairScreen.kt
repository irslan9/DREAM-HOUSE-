package com.dreamspace.calculator.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.PriceBasis
import com.dreamspace.calculator.domain.calc.StairCalculator
import com.dreamspace.calculator.domain.calc.StairResult
import com.dreamspace.calculator.domain.calc.pkr
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ResultRow
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.components.show
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ChipRow
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormMeasure
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.SectionTitle

class StairViewModel : ViewModel() {
    val form = FormState()
    var basis by mutableStateOf(PriceBasis.PER_PIECE)
    var result by mutableStateOf<StairResult?>(null)
    var message by mutableStateOf<String?>(null)

    init {
        form.values["wastage"] = "10"
        form.units["tread"] = LengthUnit.INCHES
        form.units["riser"] = LengthUnit.INCHES
        form.onEdited = { invalidate() }
    }

    fun invalidate() { result = null; message = null }
    fun setBasis(b: PriceBasis) { basis = b; invalidate() }

    fun calculate() {
        val r = FormReader(form)
        val steps = r.count("steps", "Number of steps", 500)
        val tread = r.length("tread", "Tread depth")
        val riser = r.length("riser", "Riser height")
        val width = r.length("width", "Stair width")
        val waste = r.percent("wastage", "Wastage")
        val sw = r.optLength("slab.w", "Material width")
        val sh = r.optLength("slab.h", "Material length")
        if ((sw == null) != (sh == null)) {
            r.error(if (sw == null) "slab.w" else "slab.h", "Enter both material sizes, or leave both empty.")
        }
        val price = r.optDecimal("price", "Price")
        if (r.failed || steps == null || tread == null || riser == null || width == null || waste == null) {
            message = "Check the highlighted fields."; result = null; return
        }
        val slab = if (sw != null && sh != null) Dim(sw.mm, sh.mm) else null
        when (val res = StairCalculator.calculate(steps, tread, riser, width, waste, slab, basis, price)) {
            is Parsed.Ok -> { result = res.value; message = null }
            is Parsed.Err -> { result = null; message = res.message }
        }
    }
}

@Composable
fun StairScreen(onBack: () -> Unit, vm: StairViewModel = viewModel()) {
    val form = vm.form
    ScreenScaffold("Staircase Calculator", onBack) {
        SectionTitle("Stairs")
        FormNumber(form, "steps", "Number of steps")
        FormMeasure(form, "tread", "Tread depth")
        FormMeasure(form, "riser", "Riser height")
        FormMeasure(form, "width", "Stair width")
        SectionTitle("Material piece (optional)")
        HintText("Enter a slab or sheet size to count how many pieces the treads and risers need.")
        FormMeasure(form, "slab.w", "Material width")
        FormMeasure(form, "slab.h", "Material length")
        SectionTitle("Wastage and price")
        FormNumber(form, "wastage", "Wastage (%)", hint = "Try 5, 10 or 15")
        ChipRow(listOf(PriceBasis.PER_PIECE, PriceBasis.PER_SQM, PriceBasis.PER_SQFT), vm.basis, { it.label }) { vm.setBasis(it) }
        FormNumber(form, "price", "Price in PKR (optional)", hint = "Price ${vm.basis.label}")
        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.result?.let { r ->
            ResultCard("Areas", listOf(
                ResultRow("One tread", r.treadEach.show()),
                ResultRow("All treads", r.treadTotal.show()),
                ResultRow("One riser", r.riserEach.show()),
                ResultRow("All risers", r.riserTotal.show()),
                ResultRow("Total", r.total.show()),
                ResultRow("Total with wastage", r.totalWithWastage.show()),
            ))
            val rows = ArrayList<ResultRow>()
            if (r.slabsLayout != null && r.slabsPractical != null) {
                rows.add(ResultRow("Pieces from layout", "${r.slabsLayout}"))
                rows.add(ResultRow("Pieces to buy", "${r.slabsPractical}"))
            }
            rows.add(ResultRow("Estimated cost", r.cost?.pkr() ?: "Enter a price"))
            ResultCard("Material", rows)
        }
    }
}
