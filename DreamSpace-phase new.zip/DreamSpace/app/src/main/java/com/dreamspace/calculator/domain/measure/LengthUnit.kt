package com.dreamspace.calculator.domain.measure

import java.math.BigDecimal

enum class LengthUnit(
    val label: String,
    val shortLabel: String,
    val mmPerUnit: BigDecimal,
    val hint: String,
) {
    FEET_INCHES("Feet + inches", "ft + in", BigDecimal("304.8"), "e.g. 5 ft 7 in, 5'7\" or 5-7"),
    FEET("Feet", "ft", BigDecimal("304.8"), "e.g. 10.5"),
    INCHES("Inches", "in", BigDecimal("25.4"), "e.g. 36"),
    MILLIMETERS("Millimeters", "mm", BigDecimal.ONE, "e.g. 2900"),
    CENTIMETERS("Centimeters", "cm", BigDecimal.TEN, "e.g. 280"),
    METERS("Meters", "m", BigDecimal(1000), "e.g. 3.5"),
}
