package com.dreamspace.calculator.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.OrientationMode
import com.dreamspace.calculator.domain.calc.PanelEstimate
import com.dreamspace.calculator.domain.calc.PanelLayoutEngine
import com.dreamspace.calculator.domain.calc.PriceBasis
import com.dreamspace.calculator.domain.calc.Surface
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ChipRow
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormMeasure
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.SectionTitle
import com.dreamspace.calculator.ui.form.SizeRows
import com.dreamspace.calculator.ui.panel.PanelResults

class CeilingViewModel : ViewModel() {
    val form = FormState()
    val rooms = form.list("room")
    var basis by mutableStateOf(PriceBasis.PER_PIECE)
    var estimate by mutableStateOf<PanelEstimate?>(null)
    var message by mutableStateOf<String?>(null)

    init {
        form.values["wastage"] = "10"
        form.values["board.w"] = "4"; form.units["board.w"] = LengthUnit.FEET
        form.values["board.h"] = "8"; form.units["board.h"] = LengthUnit.FEET
        form.onEdited = { invalidate() }
    }

    fun invalidate() { estimate = null; message = null }
    fun setBasis(b: PriceBasis) { basis = b; invalidate() }

    fun calculate() {
        val r = FormReader(form)
        val sizes = r.pairs(rooms, "room", "Ceiling length", "Ceiling width")
        val bw = r.length("board.w", "Board width")
        val bh = r.length("board.h", "Board length")
        val waste = r.percent("wastage", "Wastage")
        val price = r.optDecimal("price", "Price")
        if (r.failed || bw == null || bh == null || waste == null) { message = "Check the highlighted fields."; estimate = null; return }
        val surfaces = sizes.mapIndexed { i, s -> Surface("Room ${i + 1}", s.first.mm, s.second.mm) }
        when (val res = PanelLayoutEngine.estimate(surfaces, Dim(bw.mm, bh.mm), OrientationMode.AUTO, true, waste, price, basis)) {
            is Parsed.Ok -> { estimate = res.value; message = null }
            is Parsed.Err -> { estimate = null; message = res.message }
        }
    }
}

@Composable
fun CeilingScreen(onBack: () -> Unit, vm: CeilingViewModel = viewModel()) {
    val form = vm.form
    ScreenScaffold("False Ceiling Calculator", onBack) {
        SectionTitle("Ceiling areas")
        SizeRows(form, vm.rooms, "room", "Room", "Ceiling length", "Ceiling width", onChanged = vm::invalidate)
        SectionTitle("Gypsum board size")
        HintText("Standard board is 4 ft x 8 ft. Change it to match your supplier.")
        FormMeasure(form, "board.w", "Board width")
        FormMeasure(form, "board.h", "Board length")
        SectionTitle("Wastage and price")
        FormNumber(form, "wastage", "Wastage (%)", hint = "Try 5, 10 or 15")
        ChipRow(listOf(PriceBasis.PER_PIECE, PriceBasis.PER_SQM, PriceBasis.PER_SQFT), vm.basis, { it.label }) { vm.setBasis(it) }
        FormNumber(form, "price", "Price in PKR (optional)", hint = "Price ${vm.basis.label}")
        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.estimate?.let { PanelResults(it, "board", "Room") }
    }
}
