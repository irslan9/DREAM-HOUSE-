package com.dreamspace.calculator.domain.calc

import java.math.BigDecimal

/** Guillotine packing of rectangular pieces cut from identical stock sheets (offcut reuse). */
object Packer {
    data class Result(val stockUsed: Long, val freeRects: List<Dim>)

    /** Returns null when a piece cannot fit on one stock sheet. */
    fun pack(stock: Dim, pieces: List<Dim>, allowRotation: Boolean): Result? {
        val bins = ArrayList<MutableList<Dim>>()
        val sorted = pieces.sortedByDescending { it.area }
        val rotations = if (allowRotation) listOf(false, true) else listOf(false)

        for (p in sorted) {
            var bestBin = -1
            var bestIdx = -1
            var bestRot = false
            var bestArea: BigDecimal? = null
            for (bi in bins.indices) {
                val bin = bins[bi]
                for (fi in bin.indices) {
                    val f = bin[fi]
                    for (rot in rotations) {
                        val pw = if (rot) p.h else p.w
                        val ph = if (rot) p.w else p.h
                        if (pw <= f.w && ph <= f.h) {
                            val fa = f.area
                            if (bestArea == null || fa < bestArea) {
                                bestArea = fa; bestBin = bi; bestIdx = fi; bestRot = rot
                            }
                        }
                    }
                }
            }
            if (bestBin < 0) {
                var fitRot: Boolean? = null
                for (rot in rotations) {
                    val pw = if (rot) p.h else p.w
                    val ph = if (rot) p.w else p.h
                    if (pw <= stock.w && ph <= stock.h) { fitRot = rot; break }
                }
                if (fitRot == null) return null
                bins.add(mutableListOf(Dim(stock.w, stock.h)))
                bestBin = bins.size - 1
                bestIdx = 0
                bestRot = fitRot
            }
            val f = bins[bestBin].removeAt(bestIdx)
            val pw = if (bestRot) p.h else p.w
            val ph = if (bestRot) p.w else p.h
            val lw = f.w.subtract(pw)
            val lh = f.h.subtract(ph)
            val bin = bins[bestBin]
            if (lw < lh) {
                if (lw.signum() > 0) bin.add(Dim(lw, ph))
                if (lh.signum() > 0) bin.add(Dim(f.w, lh))
            } else {
                if (lw.signum() > 0) bin.add(Dim(lw, f.h))
                if (lh.signum() > 0) bin.add(Dim(pw, lh))
            }
        }
        return Result(bins.size.toLong(), bins.flatten())
    }
}
