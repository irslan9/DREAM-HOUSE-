package com.dreamspace.calculator.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BorderAll
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FormatPaint
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Stairs
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.Texture
import androidx.compose.material.icons.outlined.VerticalAlignTop
import androidx.compose.material.icons.outlined.ViewColumn
import androidx.compose.material.icons.outlined.ViewWeek
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.ui.graphics.vector.ImageVector

/** [phase] is null when the screen is built; otherwise the build phase that delivers it. */
enum class Destination(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val phase: Int?,
    val blurb: String,
) {
    FloorTile("floor_tile", "Floor Tile Calculator", Icons.Outlined.GridView, null,
        "Rectangular and multiple floor areas, tile quantity, wastage, boxes and cost."),
    WallTile("wall_tile", "Wall Tile Calculator", Icons.Outlined.BorderAll, null,
        "Multiple walls, door and window deductions, tile quantity, boxes and cost."),
    PvcPanel("pvc_panel", "PVC Panel Calculator", Icons.Outlined.ViewColumn, null,
        "Any custom panel width and height, vertical or horizontal layout, cuts and offcuts."),
    WpcPanel("wpc_panel", "WPC Panel Calculator", Icons.Outlined.ViewWeek, null,
        "Any custom panel size with a layout and cutting estimate, not area alone."),
    FlutedPanel("fluted_panel", "Decorative and Fluted Panel Calculator", Icons.Outlined.Texture, null,
        "Fluted, charcoal, marble-sheet and wooden panels with a saved panel size library."),
    MarbleGranite("marble_granite", "Marble and Granite Calculator", Icons.Outlined.Layers, null,
        "Custom slab and sheet sizes with area and piece counts."),
    Staircase("staircase", "Staircase Calculator", Icons.Outlined.Stairs, null,
        "Treads and risers: areas and material quantities."),
    FalseCeiling("false_ceiling", "False Ceiling Calculator", Icons.Outlined.VerticalAlignTop, null,
        "Ceiling area and gypsum board quantity with configurable wastage."),
    Paint("paint", "Paint Calculator", Icons.Outlined.FormatPaint, null,
        "Wall area, coats and litres from your coverage per litre."),
    Wallpaper("wallpaper", "Wallpaper Calculator", Icons.Outlined.Wallpaper, null,
        "Roll count with pattern matching and wastage."),
    CostEstimator("cost_estimator", "Cost Estimator", Icons.Outlined.Payments, null,
        "Editable PKR prices, labour, installation and extras."),
    UnitConverter("unit_converter", "Unit Converter", Icons.Outlined.SwapHoriz, null, ""),
    SavedProjects("saved_projects", "My Saved Projects", Icons.Outlined.FolderOpen, 5,
        "Whole-house projects saved on this phone: edit, duplicate and delete."),
    PdfReports("pdf_reports", "PDF Reports", Icons.Outlined.PictureAsPdf, 5,
        "Branded PDF estimates you can save or share.");

    companion object {
        val calculators = listOf(
            FloorTile, WallTile, PvcPanel, WpcPanel, FlutedPanel,
            MarbleGranite, Staircase, FalseCeiling, Paint, Wallpaper,
        )
        val tools = listOf(CostEstimator, UnitConverter, SavedProjects, PdfReports)
    }
}
