package com.dreamspace.calculator.ui.form

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.ui.components.MeasurementField

@Composable
fun FormMeasure(
    form: FormState,
    key: String,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    units: List<LengthUnit> = LengthUnit.entries,
) {
    MeasurementField(
        label = label,
        value = form.getText(key),
        unit = form.unit(key),
        onValueChange = { form.setText(key, it) },
        onUnitChange = { form.setUnit(key, it) },
        modifier = modifier,
        error = form.errors[key],
        units = units,
    )
}

@Composable
fun FormNumber(
    form: FormState,
    key: String,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    hint: String = "",
) {
    val err = form.errors[key]
    OutlinedTextField(
        value = form.getText(key),
        onValueChange = { form.setText(key, it) },
        label = { Text(label) },
        singleLine = true,
        isError = err != null,
        supportingText = { Text(err ?: hint) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
        modifier = modifier,
    )
}

@Composable
fun FormText(form: FormState, key: String, label: String, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(
        value = form.getText(key),
        onValueChange = { form.setText(key, it) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
        modifier = modifier,
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun HintText(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun ErrorNote(message: String?) {
    if (message != null) Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
        }
    }
}

@Composable
fun <T> OptionPicker(
    selected: T,
    options: List<T>,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }) {
            Text(label(selected))
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(label(o)) }, onClick = { onSelect(o); open = false })
            }
        }
    }
}

@Composable
fun RowHeader(title: String, onRemove: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (onRemove != null) {
            IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, contentDescription = "Remove $title") }
        }
    }
}

@Composable
fun AddRowButton(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.Add, contentDescription = null)
        Text(" $text")
    }
}

@Composable
fun CalculateButton(onClick: () -> Unit, text: String = "Calculate") {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(text) }
}

/** Rows of two lengths (e.g. room length + width). Keys: "<prefix><id>.a" / ".b". */
@Composable
fun SizeRows(
    form: FormState,
    list: RowList,
    prefix: String,
    itemName: String,
    labelA: String,
    labelB: String,
    minRows: Int = 1,
    onChanged: () -> Unit,
) {
    list.ids.forEachIndexed { i, id ->
        key(id) {
            RowHeader("$itemName ${i + 1}", if (list.ids.size > minRows) ({ list.remove(id); onChanged() }) else null)
            FormMeasure(form, "$prefix$id.a", labelA)
            FormMeasure(form, "$prefix$id.b", labelB)
        }
    }
    AddRowButton("Add ${itemName.lowercase()}") { list.add(); onChanged() }
}
