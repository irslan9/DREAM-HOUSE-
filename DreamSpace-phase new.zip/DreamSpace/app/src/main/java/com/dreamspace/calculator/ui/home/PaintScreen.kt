package com.dreamspace.calculator.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.PaintCalculator
import com.dreamspace.calculator.domain.calc.PaintResult
import com.dreamspace.calculator.domain.calc.Surface
import com.dreamspace.calculator.domain.calc.SurfaceMath
import com.dreamspace.calculator.domain.calc.pkr
import com.dreamspace.calculator.domain.measure.AreaUnit
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.domain.measure.display
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ResultRow
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.components.show
import com.dreamspace.calculator.ui.form.AddRowButton
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ChipRow
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormMeasure
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.RowHeader
import com.dreamspace.calculator.ui.form.SectionTitle
import com.dreamspace.calculator.ui.form.SizeRows

class PaintViewModel : ViewModel() {
    val form = FormState()
    val walls = form.list("wall")
    val openings = form.list("opening", 0)
    var coverageUnit by mutableStateOf(AreaUnit.SQUARE_FEET)
    var result by mutableStateOf<PaintResult?>(null)
    var message by mutableStateOf<String?>(null)

    init {
        form.values["wastage"] = "10"
        form.values["coats"] = "2"
        form.values["coverage"] = "100"
        form.onEdited = { invalidate() }
    }

    fun invalidate() { result = null; message = null }
    fun setCoverageUnit(u: AreaUnit) { coverageUnit = u; invalidate() }

    fun calculate() {
        val r = FormReader(form)
        val sizes = r.pairs(walls, "wall", "Wall width", "Wall height")
        val ops = r.pairs(openings, "opening", "Opening width", "Opening height")
        val coats = r.count("coats", "Coats", 20)
        val coverage = r.decimal("coverage", "Coverage per litre")
        val waste = r.percent("wastage", "Wastage")
        val can = r.optDecimal("can", "Can size")
        val price = r.optDecimal("price", "Price per litre")
        if (r.failed || coats == null || coverage == null || waste == null) { message = "Check the highlighted fields."; result = null; return }
        val surfaces = sizes.mapIndexed { i, s -> Surface("Wall ${i + 1}", s.first.mm, s.second.mm) }
        val net = when (val s = SurfaceMath.summary(surfaces, ops.map { Dim(it.first.mm, it.second.mm) })) {
            is Parsed.Ok -> s.value.net
            is Parsed.Err -> { message = s.message; result = null; return }
        }
        when (val res = PaintCalculator.calculate(net, coats, coverage, coverageUnit, waste, can, price)) {
            is Parsed.Ok -> { result = res.value; message = null }
            is Parsed.Err -> { result = null; message = res.message }
        }
    }
}

@Composable
fun PaintScreen(onBack: () -> Unit, vm: PaintViewModel = viewModel()) {
    val form = vm.form
    ScreenScaffold("Paint Calculator", onBack) {
        SectionTitle("Walls")
        SizeRows(form, vm.walls, "wall", "Wall", "Wall width", "Wall height", onChanged = vm::invalidate)
        SectionTitle("Doors and windows")
        HintText("Their area is not painted, so it is deducted.")
        vm.openings.ids.forEachIndexed { i, id ->
            key(id) {
                RowHeader("Opening ${i + 1}", { vm.openings.remove(id); vm.invalidate() })
                FormMeasure(form, "opening$id.a", "Opening width")
                FormMeasure(form, "opening$id.b", "Opening height")
            }
        }
        AddRowButton("Add door or window") { vm.openings.add(); vm.invalidate() }
        SectionTitle("Paint")
        FormNumber(form, "coats", "Number of coats")
        ChipRow(AreaUnit.entries.toList(), vm.coverageUnit, { if (it == AreaUnit.SQUARE_FEET) "ft\u00B2 per litre" else "m\u00B2 per litre" }) { vm.setCoverageUnit(it) }
        FormNumber(form, "coverage", "Coverage per litre", hint = "From the paint tin. Typical wall paint is about 100 ft\u00B2 per litre.")
        FormNumber(form, "wastage", "Wastage (%)", hint = "Try 5, 10 or 15")
        FormNumber(form, "can", "Can size in litres (optional)")
        FormNumber(form, "price", "Price per litre in PKR (optional)")
        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.result?.let { r ->
            ResultCard("Paint", buildList {
                add(ResultRow("Paintable wall area", r.net.show()))
                add(ResultRow("Area with all coats", r.coatedArea.show()))
                add(ResultRow("Litres needed (exact)", r.litresExact.display(2)))
                add(ResultRow("Litres with wastage", r.litresPractical.display(2)))
                if (r.cans != null) add(ResultRow("Cans to buy", "${r.cans}"))
                add(ResultRow("Litres bought", r.purchasedLitres.display(2)))
                add(ResultRow("Estimated cost", r.cost?.pkr() ?: "Enter a price"))
            })
        }
    }
}
