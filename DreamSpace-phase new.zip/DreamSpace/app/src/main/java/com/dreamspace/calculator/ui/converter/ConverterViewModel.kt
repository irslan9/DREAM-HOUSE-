package com.dreamspace.calculator.ui.converter

import androidx.lifecycle.ViewModel
import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.AreaUnit
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.MeasurementParser
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.domain.measure.display
import com.dreamspace.calculator.domain.measure.displayFeetInches
import com.dreamspace.calculator.ui.components.ResultRow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ConverterUiState(
    val lengthInput: String = "",
    val lengthUnit: LengthUnit = LengthUnit.FEET_INCHES,
    val lengthError: String? = null,
    val lengthRows: List<ResultRow> = emptyList(),
    val areaInput: String = "",
    val areaUnit: AreaUnit = AreaUnit.SQUARE_FEET,
    val areaError: String? = null,
    val areaRows: List<ResultRow> = emptyList(),
)

class ConverterViewModel : ViewModel() {
    private val _state = MutableStateFlow(ConverterUiState())
    val state: StateFlow<ConverterUiState> = _state.asStateFlow()

    fun onLengthInput(v: String) = _state.update { it.copy(lengthInput = v).withLength() }
    fun onLengthUnit(u: LengthUnit) = _state.update { it.copy(lengthUnit = u).withLength() }
    fun onAreaInput(v: String) = _state.update { it.copy(areaInput = v).withArea() }
    fun onAreaUnit(u: AreaUnit) = _state.update { it.copy(areaUnit = u).withArea() }
}

private fun ConverterUiState.withLength(): ConverterUiState {
    if (lengthInput.isBlank()) return copy(lengthError = null, lengthRows = emptyList())
    return when (val r = MeasurementParser.parse(lengthInput, lengthUnit, "Length")) {
        is Parsed.Ok -> copy(lengthError = null, lengthRows = lengthRowsFor(r.value))
        is Parsed.Err -> copy(lengthError = r.message, lengthRows = emptyList())
    }
}

private fun lengthRowsFor(l: Length) = listOf(
    ResultRow("Millimeters", l.mm.display(2)),
    ResultRow("Centimeters", l.cm.display(3)),
    ResultRow("Meters", l.meters.display(4)),
    ResultRow("Feet", l.feet.display(4)),
    ResultRow("Inches", l.inches.display(3)),
    ResultRow("Feet + inches", l.displayFeetInches()),
)

private fun ConverterUiState.withArea(): ConverterUiState {
    if (areaInput.isBlank()) return copy(areaError = null, areaRows = emptyList())
    return when (val r = MeasurementParser.parseDecimal(areaInput, "Area")) {
        is Parsed.Ok -> {
            val a = if (areaUnit == AreaUnit.SQUARE_FEET) Area.fromSquareFeet(r.value) else Area.fromSquareMeters(r.value)
            copy(
                areaError = null,
                areaRows = listOf(
                    ResultRow("Square feet", a.sqFeet.display(4)),
                    ResultRow("Square meters", a.sqMeters.display(4)),
                ),
            )
        }
        is Parsed.Err -> copy(areaError = r.message, areaRows = emptyList())
    }
}
