package com.dreamspace.calculator.domain.measure

import com.dreamspace.calculator.domain.measure.Precision.MC
import java.math.BigDecimal

/** 1 sq ft = 0.09290304 sq m exactly (304.8 mm x 304.8 mm = 92,903.04 mm2). */
val SQ_MM_PER_SQ_FT = BigDecimal("92903.04")
val SQ_MM_PER_SQ_M = BigDecimal("1000000")

/** An area stored internally in square millimeters. */
data class Area(val sqMm: BigDecimal) : Comparable<Area> {
    val sqMeters: BigDecimal get() = sqMm.divide(SQ_MM_PER_SQ_M, MC)
    val sqFeet: BigDecimal get() = sqMm.divide(SQ_MM_PER_SQ_FT, MC)

    operator fun plus(other: Area) = Area(sqMm.add(other.sqMm))
    operator fun minus(other: Area) = Area(sqMm.subtract(other.sqMm))
    operator fun times(factor: BigDecimal) = Area(sqMm.multiply(factor))
    override fun compareTo(other: Area): Int = sqMm.compareTo(other.sqMm)

    companion object {
        val ZERO = Area(BigDecimal.ZERO)
        fun of(a: Length, b: Length) = Area(a.mm.multiply(b.mm))
        fun fromSquareFeet(v: BigDecimal) = Area(v.multiply(SQ_MM_PER_SQ_FT))
        fun fromSquareMeters(v: BigDecimal) = Area(v.multiply(SQ_MM_PER_SQ_M))
    }
}

enum class AreaUnit(val label: String) {
    SQUARE_FEET("Square feet"),
    SQUARE_METERS("Square meters"),
}
