package com.dreamspace.calculator.domain.measure

import java.math.BigDecimal

sealed interface Parsed<out T> {
    data class Ok<T>(val value: T) : Parsed<T>
    data class Err(val message: String) : Parsed<Nothing>
}

/**
 * Turns what a person types ("5 ft 7 in", "280 mm", "10'6\"", "2.5") into an exact [Length].
 * Never throws: bad input returns [Parsed.Err] with a readable message.
 */
object MeasurementParser {
    private val MAX_MM = BigDecimal("1000000") // 1 km: anything larger is almost certainly a typo
    private val TWELVE = BigDecimal(12)

    private const val N = "(\\d+(?:\\.\\d+)?|\\.\\d+)"
    private val FEET_INCHES = Regex("^$N\\s*(?:ft|feet|foot|')\\s*(?:$N\\s*(?:in|inch|inches|\")?)?$")
    private val INCHES_ONLY = Regex("^$N\\s*(?:in|inch|inches|\")$")
    private val METRIC = Regex("^$N\\s*(mm|millimeters?|millimetres?|cm|centimeters?|centimetres?|m|meters?|metres?)$")
    private val FEET_DASH_INCHES = Regex("^$N(?:\\s*-\\s*|\\s+)$N$")
    private val PLAIN = Regex("^$N$")

    private fun normalize(raw: String): String = raw.trim().lowercase()
        .replace('\u2032', '\'').replace('\u2019', '\'').replace('\u2018', '\'')
        .replace('\u2033', '"').replace('\u201D', '"').replace('\u201C', '"')
        .replace("''", "\"")
        .replace(Regex("\\s+"), " ")

    fun parse(
        raw: String,
        defaultUnit: LengthUnit,
        fieldName: String = "Measurement",
        allowZero: Boolean = false,
    ): Parsed<Length> {
        val text = normalize(raw)
        if (text.isEmpty()) return Parsed.Err("$fieldName is required.")
        if (text.startsWith("-")) return Parsed.Err("$fieldName cannot be negative.")

        val mm: BigDecimal = when (val r = toMm(text, defaultUnit)) {
            is Parsed.Ok -> r.value
            is Parsed.Err -> return r
        }
        if (mm.signum() == 0 && !allowZero) return Parsed.Err("$fieldName must be greater than zero.")
        if (mm > MAX_MM) return Parsed.Err("$fieldName is too large. Check the unit.")
        return Parsed.Ok(Length(mm))
    }

    private fun toMm(text: String, defaultUnit: LengthUnit): Parsed<BigDecimal> {
        FEET_INCHES.matchEntire(text)?.let { m ->
            val inchesText = m.groupValues[2]
            val inches = if (inchesText.isEmpty()) BigDecimal.ZERO else BigDecimal(inchesText)
            return feetInches(BigDecimal(m.groupValues[1]), inches)
        }
        INCHES_ONLY.matchEntire(text)?.let { m ->
            return Parsed.Ok(BigDecimal(m.groupValues[1]).multiply(LengthUnit.INCHES.mmPerUnit))
        }
        METRIC.matchEntire(text)?.let { m ->
            val u = m.groupValues[2]
            val unit = when {
                u.startsWith("mm") || u.startsWith("milli") -> LengthUnit.MILLIMETERS
                u.startsWith("c") -> LengthUnit.CENTIMETERS
                else -> LengthUnit.METERS
            }
            return Parsed.Ok(BigDecimal(m.groupValues[1]).multiply(unit.mmPerUnit))
        }
        if (defaultUnit == LengthUnit.FEET_INCHES) {
            FEET_DASH_INCHES.matchEntire(text)?.let { m ->
                return feetInches(BigDecimal(m.groupValues[1]), BigDecimal(m.groupValues[2]))
            }
        }
        PLAIN.matchEntire(text)?.let { m ->
            return Parsed.Ok(BigDecimal(m.groupValues[1]).multiply(defaultUnit.mmPerUnit))
        }
        return Parsed.Err("Couldn't read \"$text\". Try 5 ft 7 in, 280 mm or 2.5 m.")
    }

    private fun feetInches(feet: BigDecimal, inches: BigDecimal): Parsed<BigDecimal> =
        if (inches >= TWELVE) Parsed.Err("Inches must be less than 12 when feet are given.")
        else Parsed.Ok(Length.ofFeetInches(feet, inches).mm)

    /** Plain decimal number (wastage %, price, counts, areas). */
    fun parseDecimal(
        raw: String,
        fieldName: String,
        allowZero: Boolean = false,
        max: BigDecimal = BigDecimal("1000000000"),
    ): Parsed<BigDecimal> {
        val text = raw.trim()
        if (text.isEmpty()) return Parsed.Err("$fieldName is required.")
        if (text.startsWith("-")) return Parsed.Err("$fieldName cannot be negative.")
        val m = PLAIN.matchEntire(text) ?: return Parsed.Err("$fieldName must be a number.")
        val v = BigDecimal(m.groupValues[1])
        if (v.signum() == 0 && !allowZero) return Parsed.Err("$fieldName must be greater than zero.")
        if (v > max) return Parsed.Err("$fieldName is too large.")
        return Parsed.Ok(v)
    }
}
