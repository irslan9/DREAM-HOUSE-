package com.dreamspace.calculator.ui.panel

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.dreamspace.calculator.domain.calc.Orientation
import com.dreamspace.calculator.domain.calc.PanelEstimate
import com.dreamspace.calculator.domain.calc.divMc
import com.dreamspace.calculator.domain.calc.pkr
import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.display
import com.dreamspace.calculator.ui.components.DiagramLegend
import com.dreamspace.calculator.ui.components.LayoutDiagram
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ResultRow
import com.dreamspace.calculator.ui.components.describe
import com.dreamspace.calculator.ui.components.show
import com.dreamspace.calculator.ui.form.ChipRow
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.SectionTitle
import java.math.BigDecimal

private fun pct(part: Area, whole: Area): String =
    if (whole.sqMm.signum() == 0) "0"
    else part.sqMm.divMc(whole.sqMm).multiply(BigDecimal(100)).display(1)

/** Shared by the panel, slab and false-ceiling calculators. [noun] is "panel", "slab" or "board". */
@Composable
fun PanelResults(e: PanelEstimate, noun: String, surfaceName: String = "Wall") {
    val c = e.chosen
    val plural = "${noun}s"
    var sel by remember { mutableStateOf(0) }

    ResultCard("Quantity to buy", listOf(
        ResultRow("Installation", c.orientation.label),
        ResultRow("Layout needs", "${c.panelsRequired} $plural"),
        ResultRow("Allowance (${e.wastagePercent.display(2)}%)", "+${e.practicalPanels - c.panelsRequired}"),
        ResultRow("To buy", "${e.practicalPanels} $plural"),
        ResultRow("Estimated cost", e.cost?.pkr() ?: "Enter a price"),
    ))

    ResultCard("Area (square feet and square meters)", listOf(
        ResultRow("${noun.replaceFirstChar { it.uppercase() }} size", e.panel.describe()),
        ResultRow("Gross area", e.gross.show()),
        ResultRow("Openings (area only)", e.openings.show()),
        ResultRow("Net area", e.net.show()),
        ResultRow("Area-only estimate", "${e.theoreticalByArea} $plural"),
    ))

    ResultCard("Layout and cuts", listOf(
        ResultRow("Full $plural", "${c.fullPanels}"),
        ResultRow("Cut pieces", "${c.cutPieces}"),
        ResultRow("$plural used for cuts", "${c.panelsFromCuts}"),
        ResultRow("Saved by openings", "${c.panelsSavedByOpenings}"),
        ResultRow("Pieces skipped (fully inside openings)", "${c.skippedCells}"),
        ResultRow("Material bought", c.purchasedArea.show()),
        ResultRow("Offcuts and waste", "${c.offcutArea.show()} (${pct(c.offcutArea, c.purchasedArea)}%)"),
        ResultRow("Reusable offcuts (50 mm+)", "${c.reusableOffcuts}"),
    ))

    ResultCard("Per $surfaceName", c.layouts.mapIndexed { i, l ->
        ResultRow("$surfaceName ${i + 1}", "${l.cols} across x ${l.rows} rows")
    })

    if (e.compared.size > 1) {
        ResultCard("Orientation comparison", e.compared.map {
            ResultRow(it.orientation.label + if (it.orientation == Orientation.VERTICAL) " (panel height up)" else " (panel turned)", "${it.panelsRequired} $plural")
        })
    }

    SectionTitle("Layout diagram")
    if (c.layouts.size > 1) {
        ChipRow(c.layouts.indices.toList(), sel, { "$surfaceName ${it + 1}" }) { sel = it }
    }
    LayoutDiagram(c.layouts[sel.coerceIn(0, c.layouts.size - 1)])
    DiagramLegend()
    HintText(
        "Quantity comes from the real layout: full $plural, cut pieces and offcut reuse. " +
            "An opening only saves $plural when you enter its position and a whole piece falls inside it. " +
            "Cut-outs around openings are not counted as extra pieces.",
    )
    Text(
        "Measurements are exact. Only whole $plural are counted.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}
