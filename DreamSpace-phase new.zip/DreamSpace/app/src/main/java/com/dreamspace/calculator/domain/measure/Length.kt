package com.dreamspace.calculator.domain.measure

import com.dreamspace.calculator.domain.measure.Precision.MC
import java.math.BigDecimal

private val MM_PER_FOOT = BigDecimal("304.8")
private val MM_PER_INCH = BigDecimal("25.4")

/** A length stored internally in millimeters (exact decimal). */
data class Length(val mm: BigDecimal) : Comparable<Length> {
    val cm: BigDecimal get() = mm.divide(BigDecimal.TEN, MC)
    val meters: BigDecimal get() = mm.divide(BigDecimal(1000), MC)
    val feet: BigDecimal get() = mm.divide(MM_PER_FOOT, MC)
    val inches: BigDecimal get() = mm.divide(MM_PER_INCH, MC)

    operator fun plus(other: Length) = Length(mm.add(other.mm))
    operator fun minus(other: Length) = Length(mm.subtract(other.mm))
    operator fun times(factor: BigDecimal) = Length(mm.multiply(factor))
    override fun compareTo(other: Length): Int = mm.compareTo(other.mm)

    fun inUnit(unit: LengthUnit): BigDecimal = mm.divide(unit.mmPerUnit, MC)

    companion object {
        val ZERO = Length(BigDecimal.ZERO)
        fun of(value: BigDecimal, unit: LengthUnit) = Length(value.multiply(unit.mmPerUnit))
        fun ofFeetInches(feet: BigDecimal, inches: BigDecimal) =
            Length(feet.multiply(MM_PER_FOOT).add(inches.multiply(MM_PER_INCH)))
    }
}
