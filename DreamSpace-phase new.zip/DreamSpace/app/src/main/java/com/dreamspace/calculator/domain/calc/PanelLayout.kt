package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal

enum class Orientation(val label: String) { VERTICAL("Vertical"), HORIZONTAL("Horizontal") }

enum class OrientationMode(val label: String) {
    VERTICAL("Vertical"), HORIZONTAL("Horizontal"), AUTO("Compare both")
}

/** Door or window. Positions are optional: only positioned openings can save whole panel pieces. */
data class Opening(
    val width: BigDecimal,
    val height: BigDecimal,
    val fromLeft: BigDecimal?,
    val fromFloor: BigDecimal?,
) {
    val positioned: Boolean get() = fromLeft != null && fromFloor != null
    val area: BigDecimal get() = width.multiply(height)
}

data class Surface(
    val name: String,
    val width: BigDecimal,
    val height: BigDecimal,
    val openings: List<Opening> = emptyList(),
)

enum class CellKind { FULL, CUT, SKIPPED }

data class Cell(val x: BigDecimal, val y: BigDecimal, val w: BigDecimal, val h: BigDecimal, val kind: CellKind)

data class SurfaceLayout(val surface: Surface, val cols: Long, val rows: Long, val cells: List<Cell>)

data class OrientationResult(
    val orientation: Orientation,
    val stock: Dim,
    val layouts: List<SurfaceLayout>,
    val fullPanels: Long,
    val cutPieces: Long,
    val panelsFromCuts: Long,
    val panelsRequired: Long,
    val skippedCells: Long,
    val panelsSavedByOpenings: Long,
    val piecesArea: Area,
    val purchasedArea: Area,
    val offcutArea: Area,
    val reusableOffcuts: Long,
)

data class PanelEstimate(
    val panel: Dim,
    val gross: Area,
    val openings: Area,
    val net: Area,
    val theoreticalByArea: Long,
    val chosen: OrientationResult,
    val compared: List<OrientationResult>,
    val wastagePercent: BigDecimal,
    val practicalPanels: Long,
    val cost: BigDecimal?,
)

data class AreaSummary(val gross: Area, val openings: Area, val net: Area)

object SurfaceMath {
    fun summary(surfaces: List<Surface>, extraOpenings: List<Dim> = emptyList()): Parsed<AreaSummary> {
        var gross = BigDecimal.ZERO
        var op = BigDecimal.ZERO
        for (s in surfaces) {
            gross = gross.add(s.width.multiply(s.height))
            for (o in s.openings) op = op.add(o.area)
        }
        for (d in extraOpenings) op = op.add(d.area)
        if (gross.signum() == 0) return Parsed.Err("Add at least one wall with a size.")
        if (op >= gross) return Parsed.Err("Doors and windows cover the whole wall area. Check their sizes.")
        return Parsed.Ok(AreaSummary(Area(gross), Area(op), Area(gross.subtract(op))))
    }
}

object PanelLayoutEngine {
    const val MAX_CELLS = 20_000L
    private const val TOO_MANY = "That is too many pieces to lay out. Check the panel size and units."
    private const val NO_FIT = "A cut piece does not fit on one panel."
    private val REUSABLE_MM = BigDecimal(50)

    fun previewLayout(s: Surface, a: BigDecimal, b: BigDecimal): SurfaceLayout? = layout(s, a, b, false)

    private fun layout(s: Surface, a: BigDecimal, b: BigDecimal, useOpenings: Boolean): SurfaceLayout? {
        val cols = s.width.divMc(a).ceilLong()
        val rows = s.height.divMc(b).ceilLong()
        if (cols > MAX_CELLS || rows > MAX_CELLS || cols * rows > MAX_CELLS) return null
        val ops = if (useOpenings) s.openings.filter { it.positioned } else emptyList()
        val cells = ArrayList<Cell>((cols * rows).toInt())
        for (r in 0 until rows) {
            val y0 = b.multiply(r.toBd())
            val y1 = minOf(y0.add(b), s.height)
            for (c in 0 until cols) {
                val x0 = a.multiply(c.toBd())
                val x1 = minOf(x0.add(a), s.width)
                val cw = x1.subtract(x0)
                val ch = y1.subtract(y0)
                val skipped = ops.any { o ->
                    val ox = o.fromLeft!!
                    val oy = o.fromFloor!!
                    x0 >= ox && x1 <= ox.add(o.width) && y0 >= oy && y1 <= oy.add(o.height)
                }
                val kind = when {
                    skipped -> CellKind.SKIPPED
                    cw.compareTo(a) == 0 && ch.compareTo(b) == 0 -> CellKind.FULL
                    else -> CellKind.CUT
                }
                cells.add(Cell(x0, y0, cw, ch, kind))
            }
        }
        return SurfaceLayout(s, cols, rows, cells)
    }

    private class Tally(
        val full: Long, val cuts: Long, val skipped: Long,
        val stocksForCuts: Long, val free: List<Dim>, val piecesArea: BigDecimal,
    ) { val required: Long get() = full + stocksForCuts }

    private fun tally(layouts: List<SurfaceLayout>, stock: Dim, rotate: Boolean): Tally? {
        var full = 0L
        var skipped = 0L
        var area = BigDecimal.ZERO
        val cuts = ArrayList<Dim>()
        for (l in layouts) {
            for (c in l.cells) {
                when (c.kind) {
                    CellKind.FULL -> { full++; area = area.add(c.w.multiply(c.h)) }
                    CellKind.CUT -> { cuts.add(Dim(c.w, c.h)); area = area.add(c.w.multiply(c.h)) }
                    CellKind.SKIPPED -> skipped++
                }
            }
        }
        val packed = Packer.pack(stock, cuts, rotate) ?: return null
        return Tally(full, cuts.size.toLong(), skipped, packed.stockUsed, packed.freeRects, area)
    }

    fun evaluate(surfaces: List<Surface>, panel: Dim, o: Orientation, allowRotate: Boolean): Parsed<OrientationResult> {
        val a = if (o == Orientation.VERTICAL) panel.w else panel.h
        val b = if (o == Orientation.VERTICAL) panel.h else panel.w
        val withOps = ArrayList<SurfaceLayout>()
        val withoutOps = ArrayList<SurfaceLayout>()
        for (s in surfaces) {
            withOps.add(layout(s, a, b, true) ?: return Parsed.Err(TOO_MANY))
            withoutOps.add(layout(s, a, b, false) ?: return Parsed.Err(TOO_MANY))
        }
        val stock = Dim(a, b)
        val main = tally(withOps, stock, allowRotate) ?: return Parsed.Err(NO_FIT)
        val baseline = if (main.skipped == 0L) main else (tally(withoutOps, stock, allowRotate) ?: return Parsed.Err(NO_FIT))
        val purchased = Area(stock.area.multiply(main.required.toBd()))
        val pieces = Area(main.piecesArea)
        return Parsed.Ok(
            OrientationResult(
                orientation = o,
                stock = stock,
                layouts = withOps,
                fullPanels = main.full,
                cutPieces = main.cuts,
                panelsFromCuts = main.stocksForCuts,
                panelsRequired = main.required,
                skippedCells = main.skipped,
                panelsSavedByOpenings = baseline.required - main.required,
                piecesArea = pieces,
                purchasedArea = purchased,
                offcutArea = purchased - pieces,
                reusableOffcuts = main.free.count { it.w >= REUSABLE_MM && it.h >= REUSABLE_MM }.toLong(),
            ),
        )
    }

    private fun validate(surfaces: List<Surface>): String? {
        for (s in surfaces) {
            if (s.width.signum() <= 0 || s.height.signum() <= 0) return "${s.name} needs a width and height."
            var openingArea = BigDecimal.ZERO
            for (o in s.openings) {
                if (o.width > s.width || o.height > s.height) return "${s.name}: an opening is larger than the wall."
                if (o.positioned && (o.fromLeft!!.add(o.width) > s.width || o.fromFloor!!.add(o.height) > s.height)) {
                    return "${s.name}: an opening extends past the edge of the wall."
                }
                openingArea = openingArea.add(o.area)
            }
            if (openingArea >= s.width.multiply(s.height)) return "${s.name}: openings cover the whole wall."
        }
        return null
    }

    fun estimate(
        surfaces: List<Surface>,
        panel: Dim,
        mode: OrientationMode,
        allowRotate: Boolean,
        wastagePercent: BigDecimal,
        price: BigDecimal?,
        basis: PriceBasis,
    ): Parsed<PanelEstimate> {
        if (surfaces.isEmpty()) return Parsed.Err("Add at least one wall.")
        validate(surfaces)?.let { return Parsed.Err(it) }
        val summary = when (val s = SurfaceMath.summary(surfaces)) {
            is Parsed.Ok -> s.value
            is Parsed.Err -> return s
        }
        val orientations = when (mode) {
            OrientationMode.VERTICAL -> listOf(Orientation.VERTICAL)
            OrientationMode.HORIZONTAL -> listOf(Orientation.HORIZONTAL)
            OrientationMode.AUTO -> listOf(Orientation.VERTICAL, Orientation.HORIZONTAL)
        }
        val results = ArrayList<OrientationResult>()
        for (o in orientations) {
            when (val r = evaluate(surfaces, panel, o, allowRotate)) {
                is Parsed.Ok -> results.add(r.value)
                is Parsed.Err -> return r
            }
        }
        val chosen = results.sortedWith(
            compareBy<OrientationResult>({ it.panelsRequired }, { it.offcutArea.sqMm }),
        ).first()
        val practical = chosen.panelsRequired.toBd().withAllowance(wastagePercent).ceilLong()
        val theoretical = summary.net.sqMm.divMc(panel.area).ceilLong()
        val cost = price?.let { Pricing.pieceCost(basis, it, practical, panel.areaValue, null) }
        return Parsed.Ok(
            PanelEstimate(panel, summary.gross, summary.openings, summary.net, theoretical, chosen, results, wastagePercent, practical, cost),
        )
    }
}
