package com.dreamspace.calculator.ui.converter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.measure.AreaUnit
import com.dreamspace.calculator.ui.components.MeasurementField
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ScreenScaffold

@Composable
fun ConverterScreen(onBack: () -> Unit, vm: ConverterViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()

    ScreenScaffold(title = "Unit Converter", onBack = onBack) {
        Text("Length", style = MaterialTheme.typography.headlineSmall)
        MeasurementField(
            label = "Length",
            value = s.lengthInput,
            unit = s.lengthUnit,
            onValueChange = vm::onLengthInput,
            onUnitChange = vm::onLengthUnit,
            error = s.lengthError,
        )
        if (s.lengthRows.isNotEmpty()) ResultCard("Converted", s.lengthRows)

        Text("Area", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AreaUnit.entries.forEach { u ->
                FilterChip(
                    selected = s.areaUnit == u,
                    onClick = { vm.onAreaUnit(u) },
                    label = { Text(u.label) },
                )
            }
        }
        OutlinedTextField(
            value = s.areaInput,
            onValueChange = vm::onAreaInput,
            label = { Text("Area") },
            singleLine = true,
            isError = s.areaError != null,
            supportingText = { Text(s.areaError ?: "e.g. 120") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
        )
        if (s.areaRows.isNotEmpty()) ResultCard("Converted", s.areaRows)
    }
}
