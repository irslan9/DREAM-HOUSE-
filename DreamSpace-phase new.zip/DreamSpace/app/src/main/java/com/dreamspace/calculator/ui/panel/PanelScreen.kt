package com.dreamspace.calculator.ui.panel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.OrientationMode
import com.dreamspace.calculator.domain.calc.PriceBasis
import com.dreamspace.calculator.domain.calc.plain
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.components.describe
import com.dreamspace.calculator.ui.form.AddRowButton
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ChipRow
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormMeasure
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.RowHeader
import com.dreamspace.calculator.ui.form.SectionTitle

private class DialogData(
    val id: Long?, val name: String,
    val w: String, val wUnit: LengthUnit, val h: String, val hUnit: LengthUnit,
)

@Composable
fun PanelScreen(title: String, preset: PanelType, onBack: () -> Unit, vm: PanelViewModel = viewModel()) {
    LaunchedEffect(preset) { vm.initType(preset) }
    val form = vm.form
    var dialog by remember { mutableStateOf<DialogData?>(null) }
    val noun = if (vm.type == PanelType.MARBLE_GRANITE || vm.type == PanelType.MARBLE_SHEET) "slab" else "panel"

    ScreenScaffold(title, onBack) {
        SectionTitle("Material")
        ChipRow(PanelType.entries.toList(), vm.type, { it.label }) { vm.setType(it) }

        SectionTitle("Panel size")
        HintText("Type any width and height, each with its own unit. Example: 10 in x 10 ft, or 280 mm x 2900 mm.")
        FormMeasure(form, "panel.w", "Panel width")
        FormMeasure(form, "panel.h", "Panel height / length")

        SectionTitle("Saved panel sizes")
        if (vm.saved.isEmpty()) HintText("No saved sizes yet.")
        vm.saved.forEach { p ->
            key(p.id) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        Text(Dim(p.widthMm, p.heightMm).describe(), style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { vm.usePanel(p) }) { Text("Use") }
                    IconButton(onClick = {
                        dialog = DialogData(p.id, p.name, p.widthMm.plain(), LengthUnit.MILLIMETERS, p.heightMm.plain(), LengthUnit.MILLIMETERS)
                    }) { Icon(Icons.Filled.Edit, contentDescription = "Edit ${p.name}") }
                    IconButton(onClick = { vm.deletePanel(p.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete ${p.name}") }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
        AddRowButton("Save a panel size") {
            dialog = DialogData(null, "", form.getText("panel.w"), form.unit("panel.w"), form.getText("panel.h"), form.unit("panel.h"))
        }

        SectionTitle("Walls")
        vm.walls.ids.forEachIndexed { i, id ->
            key(id) { WallEditor(vm, i, id) }
        }
        AddRowButton("Add wall") { vm.walls.add(); vm.invalidate() }

        SectionTitle("Installation")
        ChipRow(OrientationMode.entries.toList(), vm.mode, { it.label }) { vm.setMode(it) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Turn offcuts 90 degrees", style = MaterialTheme.typography.titleMedium)
                HintText("Leave off for fluted or wood-grain material.")
            }
            Switch(checked = vm.allowRotate, onCheckedChange = { vm.setRotate(it) })
        }

        SectionTitle("Allowance and price")
        FormNumber(form, "wastage", "Wastage allowance (%)", hint = "Try 5, 10 or 15")
        ChipRow(listOf(PriceBasis.PER_PIECE, PriceBasis.PER_SQM, PriceBasis.PER_SQFT), vm.basis, { it.label }) { vm.setBasis(it) }
        FormNumber(form, "price", "Price in PKR (optional)", hint = "Price ${vm.basis.label}")

        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.estimate?.let { PanelResults(it, noun) }
    }

    dialog?.let { d ->
        PanelEditDialog(
            data = d,
            onDismiss = { dialog = null },
            onSave = { name, w, h -> vm.savePanel(d.id, name, w, h); dialog = null },
        )
    }
}

@Composable
private fun WallEditor(vm: PanelViewModel, index: Int, id: Int) {
    val form = vm.form
    RowHeader("Wall ${index + 1}", if (vm.walls.ids.size > 1) ({ vm.removeWall(id) }) else null)
    FormMeasure(form, "wall$id.w", "Wall width")
    FormMeasure(form, "wall$id.h", "Wall height")
    val ops = form.list("wall$id.o", 0)
    ops.ids.forEachIndexed { oi, oid ->
        key(oid) {
            val p = "wall$id.o$oid"
            val window = form.flag("$p.window")
            RowHeader("Opening ${oi + 1}", { vm.removeOpening(ops, oid) })
            ChipRow(listOf("Door", "Window"), if (window) "Window" else "Door", { it }) { form.setFlag("$p.window", it == "Window") }
            FormMeasure(form, "$p.w", "Opening width")
            FormMeasure(form, "$p.h", "Opening height")
            FormMeasure(form, "$p.left", "Distance from wall's left edge (optional)")
            if (window) FormMeasure(form, "$p.floor", "Height from floor (optional)")
        }
    }
    AddRowButton("Add door or window to wall ${index + 1}") { ops.add(); vm.invalidate() }
}

@Composable
private fun PanelEditDialog(data: DialogData, onDismiss: () -> Unit, onSave: (String, Length, Length) -> Unit) {
    val local = remember {
        FormState().also {
            it.values["w"] = data.w; it.units["w"] = data.wUnit
            it.values["h"] = data.h; it.units["h"] = data.hUnit
        }
    }
    var name by remember { mutableStateOf(data.name) }
    var nameError by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Panel size") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it; nameError = null },
                    label = { Text("Name") }, singleLine = true, isError = nameError != null,
                    supportingText = { Text(nameError ?: "") }, modifier = Modifier.fillMaxWidth(),
                )
                FormMeasure(local, "w", "Width")
                FormMeasure(local, "h", "Height / length")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = FormReader(local)
                val w = r.length("w", "Width")
                val h = r.length("h", "Height")
                if (name.isBlank()) nameError = "Enter a name"
                else if (w != null && h != null) onSave(name.trim(), w, h)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
