package com.dreamspace.calculator.ui.components

import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.display
import com.dreamspace.calculator.domain.measure.displayFeetInches

fun Area.show(): String = "${sqFeet.display(2)} ft\u00B2 / ${sqMeters.display(3)} m\u00B2"

fun Dim.describe(): String =
    "${w.display(1)} x ${h.display(1)} mm (${Length(w).displayFeetInches()} x ${Length(h).displayFeetInches()})"
