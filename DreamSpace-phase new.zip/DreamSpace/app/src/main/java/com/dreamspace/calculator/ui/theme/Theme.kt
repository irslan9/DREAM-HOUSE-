package com.dreamspace.calculator.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF2A2A2D),            // charcoal
    onPrimary = Color(0xFFFBF7EE),          // ivory
    primaryContainer = Color(0xFFF1E3BD),   // champagne
    onPrimaryContainer = Color(0xFF3B2F10),
    secondary = Color(0xFF8A6A22),          // deep gold, readable on ivory
    onSecondary = Color.White,
    background = Color(0xFFFAF6EC),
    onBackground = Color(0xFF232326),
    surface = Color.White,
    onSurface = Color(0xFF232326),
    surfaceVariant = Color(0xFFF3ECDB),
    onSurfaceVariant = Color(0xFF5A554A),
    outline = Color(0xFFB9AC8A),
    outlineVariant = Color(0xFFE3D9BF),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE6CD8A),
    onPrimary = Color(0xFF2A2210),
    primaryContainer = Color(0xFF4A3E1F),
    onPrimaryContainer = Color(0xFFF4E5BB),
    secondary = Color(0xFFD9BC6C),
    onSecondary = Color(0xFF2A2210),
    background = Color(0xFF18181A),
    onBackground = Color(0xFFEDE8DC),
    surface = Color(0xFF222225),
    onSurface = Color(0xFFEDE8DC),
    surfaceVariant = Color(0xFF2C2C30),
    onSurfaceVariant = Color(0xFFB9B2A2),
    outline = Color(0xFF7C7566),
    outlineVariant = Color(0xFF3E3B34),
)

private val Serif = FontFamily.Serif

private val DreamTypography = Typography().copy(
    displaySmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 32.sp, lineHeight = 40.sp, letterSpacing = 6.sp),
    headlineSmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Normal, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.1.sp),
)

@Composable
fun DreamSpaceTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = DreamTypography,
        content = content,
    )
}
