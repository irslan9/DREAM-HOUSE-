package com.dreamspace.calculator.ui.panel

import android.content.Context
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

data class SavedPanel(val id: Long, val name: String, val widthMm: BigDecimal, val heightMm: BigDecimal)

/** Saved market panel sizes, stored on the phone. Works fully offline. */
class PanelLibrary(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("dreamspace_panel_library", Context.MODE_PRIVATE)

    init {
        if (!prefs.getBoolean("seeded", false)) {
            write(
                listOf(
                    SavedPanel(1, "Panel A: 10 in x 10 ft", BigDecimal("254"), BigDecimal("3048")),
                    SavedPanel(2, "Panel B: 1 ft x 8 ft", BigDecimal("304.8"), BigDecimal("2438.4")),
                    SavedPanel(3, "Panel C: 2 ft x 10 ft", BigDecimal("609.6"), BigDecimal("3048")),
                    SavedPanel(4, "Panel D: 280 mm x 2900 mm", BigDecimal("280"), BigDecimal("2900")),
                ),
            )
            prefs.edit().putBoolean("seeded", true).apply()
        }
    }

    fun all(): List<SavedPanel> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            SavedPanel(o.getLong("id"), o.getString("name"), BigDecimal(o.getString("w")), BigDecimal(o.getString("h")))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun upsert(p: SavedPanel) {
        val list = all().toMutableList()
        val i = list.indexOfFirst { it.id == p.id }
        if (i >= 0) list[i] = p else list.add(p)
        write(list)
    }

    fun delete(id: Long) = write(all().filter { it.id != id })

    private fun write(list: List<SavedPanel>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("w", it.widthMm.toPlainString()).put("h", it.heightMm.toPlainString()))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
