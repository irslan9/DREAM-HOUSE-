package com.dreamspace.calculator.domain.measure

import java.math.MathContext
import java.math.RoundingMode

/** All divisions use 34 significant digits. Values are never rounded until display. */
object Precision {
    val MC: MathContext = MathContext(34, RoundingMode.HALF_EVEN)
}
