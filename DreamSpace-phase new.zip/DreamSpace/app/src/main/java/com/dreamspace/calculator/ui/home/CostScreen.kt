package com.dreamspace.calculator.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.CostEstimator
import com.dreamspace.calculator.domain.calc.CostLine
import com.dreamspace.calculator.domain.calc.CostResult
import com.dreamspace.calculator.domain.calc.CostUnit
import com.dreamspace.calculator.domain.calc.pkr
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ResultRow
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.form.AddRowButton
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.FormText
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.OptionPicker
import com.dreamspace.calculator.ui.form.RowHeader
import com.dreamspace.calculator.ui.form.SectionTitle

class CostViewModel : ViewModel() {
    val form = FormState()
    val lines = form.list("line")
    val qtyUnits = mutableStateMapOf<Int, CostUnit>()
    val priceUnits = mutableStateMapOf<Int, CostUnit>()
    var result by mutableStateOf<CostResult?>(null)
    var names by mutableStateOf<List<String>>(emptyList())
    var message by mutableStateOf<String?>(null)

    init {
        form.values["wastage"] = "10"
        form.onEdited = { invalidate() }
    }

    fun invalidate() { result = null; message = null }
    fun qtyUnit(id: Int): CostUnit = qtyUnits[id] ?: CostUnit.SQ_FT
    fun priceUnit(id: Int): CostUnit = priceUnits[id] ?: CostUnit.SQ_FT
    fun setQty(id: Int, u: CostUnit) { qtyUnits[id] = u; invalidate() }
    fun setPrice(id: Int, u: CostUnit) { priceUnits[id] = u; invalidate() }

    fun calculate() {
        val r = FormReader(form)
        val items = ArrayList<CostLine>()
        lines.ids.forEachIndexed { i, id ->
            val name = form.getText("line$id.name").ifBlank { "Item ${i + 1}" }
            val qty = r.decimal("line$id.qty", "Quantity")
            val price = r.decimal("line$id.price", "Price", allowZero = true)
            if (qty != null && price != null) items.add(CostLine(name, qty, qtyUnit(id), price, priceUnit(id)))
        }
        val waste = r.percent("wastage", "Wastage")
        val labour = r.optDecimal("labour", "Labour")
        val install = r.optDecimal("install", "Installation")
        val extra = r.optDecimal("extra", "Additional expenses")
        if (r.failed || waste == null) { message = "Check the highlighted fields."; result = null; return }
        val zero = java.math.BigDecimal.ZERO
        when (val res = CostEstimator.estimate(items, waste, labour ?: zero, install ?: zero, extra ?: zero)) {
            is Parsed.Ok -> { result = res.value; names = items.map { it.name }; message = null }
            is Parsed.Err -> { result = null; message = res.message }
        }
    }
}

@Composable
fun CostScreen(onBack: () -> Unit, vm: CostViewModel = viewModel()) {
    val form = vm.form
    val units = CostUnit.entries.toList()
    ScreenScaffold("Cost Estimator", onBack) {
        SectionTitle("Materials")
        HintText("Quantity and price can use different area units. Panels, tiles and boxes must match.")
        vm.lines.ids.forEachIndexed { i, id ->
            key(id) {
                RowHeader("Item ${i + 1}", if (vm.lines.ids.size > 1) ({ vm.lines.remove(id); vm.invalidate() }) else null)
                FormText(form, "line$id.name", "Name (e.g. PVC panels)")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                    FormNumber(form, "line$id.qty", "Quantity", Modifier.weight(1f))
                    OptionPicker(vm.qtyUnit(id), units, { it.label }, { vm.setQty(id, it) })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                    FormNumber(form, "line$id.price", "Price in PKR", Modifier.weight(1f))
                    Text("per")
                    OptionPicker(vm.priceUnit(id), units, { it.label }, { vm.setPrice(id, it) })
                }
            }
        }
        AddRowButton("Add material") { vm.lines.add(); vm.invalidate() }
        SectionTitle("Other costs (PKR)")
        FormNumber(form, "wastage", "Wastage on materials (%)", hint = "Try 5, 10 or 15")
        FormNumber(form, "labour", "Labour charges (optional)")
        FormNumber(form, "install", "Installation charges (optional)")
        FormNumber(form, "extra", "Additional expenses (optional)")
        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.result?.let { r ->
            ResultCard("Estimate", buildList {
                r.lineTotals.forEachIndexed { i, t -> add(ResultRow(vm.names.getOrElse(i) { "Item ${i + 1}" }, t.pkr())) }
                add(ResultRow("Subtotal", r.subtotal.pkr()))
                add(ResultRow("Wastage cost", r.wastageCost.pkr()))
                add(ResultRow("Labour", r.labour.pkr()))
                add(ResultRow("Installation", r.installation.pkr()))
                add(ResultRow("Additional", r.additional.pkr()))
                add(ResultRow("Grand total", r.grandTotal.pkr()))
            })
        }
    }
}
