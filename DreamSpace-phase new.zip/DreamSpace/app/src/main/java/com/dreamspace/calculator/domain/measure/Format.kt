package com.dreamspace.calculator.domain.measure

import java.math.BigDecimal
import java.math.RoundingMode

/** Display-only rounding. Calculations never use these. */
fun BigDecimal.display(scale: Int = 2): String =
    setScale(scale, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

fun Length.displayFeetInches(): String {
    val twelve = BigDecimal(12)
    val totalInches = inches.setScale(2, RoundingMode.HALF_UP)
    val feet = totalInches.divideToIntegralValue(twelve).toBigInteger()
    val rest = totalInches.subtract(BigDecimal(feet).multiply(twelve))
    val inchText = rest.display(2)
    return when {
        feet.signum() == 0 -> "$inchText in"
        rest.signum() == 0 -> "$feet ft"
        else -> "$feet ft $inchText in"
    }
}
