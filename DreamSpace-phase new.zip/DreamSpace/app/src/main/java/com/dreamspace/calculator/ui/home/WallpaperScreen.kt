package com.dreamspace.calculator.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.WallpaperCalculator
import com.dreamspace.calculator.domain.calc.WallpaperResult
import com.dreamspace.calculator.domain.calc.pkr
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.domain.measure.displayFeetInches
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ResultRow
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.components.show
import com.dreamspace.calculator.ui.form.AddRowButton
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormMeasure
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.RowHeader
import com.dreamspace.calculator.ui.form.SectionTitle
import com.dreamspace.calculator.ui.form.SizeRows

class WallpaperViewModel : ViewModel() {
    val form = FormState()
    val walls = form.list("wall")
    val openings = form.list("opening", 0)
    var result by mutableStateOf<WallpaperResult?>(null)
    var message by mutableStateOf<String?>(null)

    init {
        form.values["wastage"] = "10"
        form.values["roll.w"] = "53"; form.units["roll.w"] = LengthUnit.CENTIMETERS
        form.values["roll.l"] = "10"; form.units["roll.l"] = LengthUnit.METERS
        form.units["repeat"] = LengthUnit.CENTIMETERS
        form.units["trim"] = LengthUnit.CENTIMETERS
        form.onEdited = { invalidate() }
    }

    fun invalidate() { result = null; message = null }

    fun calculate() {
        val r = FormReader(form)
        val sizes = r.pairs(walls, "wall", "Wall width", "Wall height")
        val ops = r.pairs(openings, "opening", "Opening width", "Opening height")
        val rw = r.length("roll.w", "Roll width")
        val rl = r.length("roll.l", "Roll length")
        val repeat = r.optLength("repeat", "Pattern repeat")
        val trim = r.optLength("trim", "Trim allowance") ?: Length.ZERO
        val waste = r.percent("wastage", "Wastage")
        val price = r.optDecimal("price", "Price per roll")
        if (r.failed || rw == null || rl == null || waste == null) { message = "Check the highlighted fields."; result = null; return }
        val res = WallpaperCalculator.calculate(
            sizes.map { Dim(it.first.mm, it.second.mm) }, ops.map { Dim(it.first.mm, it.second.mm) },
            rw.mm, rl.mm, repeat?.mm, trim.mm, waste, price,
        )
        when (res) {
            is Parsed.Ok -> { result = res.value; message = null }
            is Parsed.Err -> { result = null; message = res.message }
        }
    }
}

@Composable
fun WallpaperScreen(onBack: () -> Unit, vm: WallpaperViewModel = viewModel()) {
    val form = vm.form
    ScreenScaffold("Wallpaper Calculator", onBack) {
        SectionTitle("Walls")
        SizeRows(form, vm.walls, "wall", "Wall", "Wall width", "Wall height", onChanged = vm::invalidate)
        SectionTitle("Doors and windows")
        HintText("Their area is shown as a deduction. Strips are not reduced, which keeps the estimate safe.")
        vm.openings.ids.forEachIndexed { i, id ->
            key(id) {
                RowHeader("Opening ${i + 1}", { vm.openings.remove(id); vm.invalidate() })
                FormMeasure(form, "opening$id.a", "Opening width")
                FormMeasure(form, "opening$id.b", "Opening height")
            }
        }
        AddRowButton("Add door or window") { vm.openings.add(); vm.invalidate() }
        SectionTitle("Roll")
        FormMeasure(form, "roll.w", "Roll width")
        FormMeasure(form, "roll.l", "Roll length")
        FormMeasure(form, "repeat", "Pattern repeat (optional)")
        FormMeasure(form, "trim", "Trim allowance per strip (optional)")
        FormNumber(form, "wastage", "Wastage (%)", hint = "Try 5, 10 or 15")
        FormNumber(form, "price", "Price per roll in PKR (optional)")
        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.result?.let { r ->
            ResultCard("Rolls", listOf(
                ResultRow("Wall area after openings", r.net.show()),
                ResultRow("Strip length used", Length(r.stripLength).displayFeetInches()),
                ResultRow("Strips per roll", "${r.dropsPerRoll}"),
                ResultRow("Strips needed", "${r.strips}"),
                ResultRow("Rolls (theoretical)", "${r.rollsTheoretical}"),
                ResultRow("Rolls to buy (with wastage)", "${r.rollsPractical}"),
                ResultRow("Estimated cost", r.cost?.pkr() ?: "Enter a price"),
            ))
            HintText("With a pattern repeat, each strip is rounded up to a whole number of repeats so the pattern lines up.")
        }
    }
}
