package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.AreaUnit
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal

// ---------------- Staircase ----------------
data class StairResult(
    val treadEach: Area,
    val treadTotal: Area,
    val riserEach: Area,
    val riserTotal: Area,
    val total: Area,
    val totalWithWastage: Area,
    val slabsLayout: Long?,
    val slabsPractical: Long?,
    val cost: BigDecimal?,
)

object StairCalculator {
    fun calculate(
        steps: Long,
        tread: Length,
        riser: Length,
        width: Length,
        wastagePercent: BigDecimal,
        slab: Dim?,
        basis: PriceBasis,
        price: BigDecimal?,
    ): Parsed<StairResult> {
        if (steps < 1) return Parsed.Err("Number of steps must be at least 1.")
        val n = steps.toBd()
        val treadEach = Area.of(tread, width)
        val riserEach = Area.of(riser, width)
        val treadTotal = treadEach * n
        val riserTotal = riserEach * n
        val total = treadTotal + riserTotal
        val withWastage = Area(total.sqMm.withAllowance(wastagePercent))

        var layout: Long? = null
        var practical: Long? = null
        if (slab != null) {
            val pieces = ArrayList<Dim>()
            repeat(steps.toInt()) {
                pieces.add(Dim(width.mm, tread.mm))
                pieces.add(Dim(width.mm, riser.mm))
            }
            val packed = Packer.pack(slab, pieces, true)
                ?: return Parsed.Err("The material piece is too small for one tread or riser.")
            layout = packed.stockUsed
            practical = packed.stockUsed.toBd().withAllowance(wastagePercent).ceilLong()
        }
        val cost: BigDecimal? = when {
            price == null -> null
            slab != null && practical != null -> Pricing.pieceCost(basis, price, practical, slab.areaValue, null)
            basis == PriceBasis.PER_SQM || basis == PriceBasis.PER_SQFT -> Pricing.areaCost(basis, price, withWastage)
            else -> return Parsed.Err("Enter the material piece size to price per piece.")
        }
        return Parsed.Ok(StairResult(treadEach, treadTotal, riserEach, riserTotal, total, withWastage, layout, practical, cost))
    }
}

// ---------------- Paint ----------------
data class PaintResult(
    val net: Area,
    val coatedArea: Area,
    val litresExact: BigDecimal,
    val litresPractical: BigDecimal,
    val cans: Long?,
    val purchasedLitres: BigDecimal,
    val cost: BigDecimal?,
)

object PaintCalculator {
    fun calculate(
        net: Area,
        coats: Long,
        coverage: BigDecimal,
        coverageUnit: AreaUnit,
        wastagePercent: BigDecimal,
        canLitres: BigDecimal?,
        pricePerLitre: BigDecimal?,
    ): Parsed<PaintResult> {
        if (coats < 1) return Parsed.Err("Coats must be at least 1.")
        val coverageSqM =
            if (coverageUnit == AreaUnit.SQUARE_METERS) coverage else Area.fromSquareFeet(coverage).sqMeters
        val coated = net * coats.toBd()
        val exact = coated.sqMeters.divMc(coverageSqM)
        val practical = exact.withAllowance(wastagePercent)
        val cans = canLitres?.let { practical.divMc(it).ceilLong() }
        val purchased = if (cans != null && canLitres != null) cans.toBd().multiply(canLitres) else practical
        val cost = pricePerLitre?.multiply(purchased)
        return Parsed.Ok(PaintResult(net, coated, exact, practical, cans, purchased, cost))
    }
}

// ---------------- Wallpaper ----------------
data class WallpaperResult(
    val net: Area,
    val stripLength: BigDecimal,
    val dropsPerRoll: Long,
    val strips: Long,
    val rollsTheoretical: Long,
    val rollsPractical: Long,
    val cost: BigDecimal?,
)

object WallpaperCalculator {
    fun calculate(
        walls: List<Dim>,
        openings: List<Dim>,
        rollWidth: BigDecimal,
        rollLength: BigDecimal,
        repeat: BigDecimal?,
        trim: BigDecimal,
        wastagePercent: BigDecimal,
        pricePerRoll: BigDecimal?,
    ): Parsed<WallpaperResult> {
        val surfaces = walls.mapIndexed { i, d -> Surface("Wall ${i + 1}", d.w, d.h) }
        val net = when (val s = SurfaceMath.summary(surfaces, openings)) {
            is Parsed.Ok -> s.value.net
            is Parsed.Err -> return s
        }
        var maxStrip = BigDecimal.ZERO
        var strips = 0L
        for (d in walls) {
            var len = d.h.add(trim)
            if (repeat != null && repeat.signum() > 0) {
                len = len.divMc(repeat).ceilLong().toBd().multiply(repeat)
            }
            if (len > maxStrip) maxStrip = len
            strips += d.w.divMc(rollWidth).ceilLong()
        }
        if (maxStrip > rollLength) return Parsed.Err("A wall is taller than one roll. Check the roll length or wall height.")
        val drops = rollLength.divMc(maxStrip).floorLong()
        val exact = strips.toBd().divMc(drops.toBd())
        val theoretical = exact.ceilLong()
        val practical = exact.withAllowance(wastagePercent).ceilLong()
        val cost = pricePerRoll?.multiply(practical.toBd())
        return Parsed.Ok(WallpaperResult(net, maxStrip, drops, strips, theoretical, practical, cost))
    }
}
