package com.dreamspace.calculator.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dreamspace.calculator.domain.measure.LengthUnit

/** Reusable length input: free text (accepts "5 ft 7 in") plus its own unit selector. */
@Composable
fun MeasurementField(
    label: String,
    value: String,
    unit: LengthUnit,
    onValueChange: (String) -> Unit,
    onUnitChange: (LengthUnit) -> Unit,
    modifier: Modifier = Modifier,
    error: String? = null,
    units: List<LengthUnit> = LengthUnit.entries,
) {
    Row(modifier, verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            singleLine = true,
            isError = error != null,
            supportingText = { Text(error ?: unit.hint) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
            modifier = Modifier.weight(1f),
        )
        UnitPicker(unit, units, onUnitChange, Modifier.padding(top = 8.dp))
    }
}

@Composable
fun UnitPicker(
    selected: LengthUnit,
    units: List<LengthUnit>,
    onSelected: (LengthUnit) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.height(56.dp)) {
            Text(selected.shortLabel)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = "Choose unit")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            units.forEach { u ->
                DropdownMenuItem(text = { Text(u.label) }, onClick = { onSelected(u); expanded = false })
            }
        }
    }
}
