package com.dreamspace.calculator.ui.tile

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.PanelLayoutEngine
import com.dreamspace.calculator.domain.calc.PriceBasis
import com.dreamspace.calculator.domain.calc.Surface
import com.dreamspace.calculator.domain.calc.SurfaceLayout
import com.dreamspace.calculator.domain.calc.TileCalculator
import com.dreamspace.calculator.domain.calc.TileInput
import com.dreamspace.calculator.domain.calc.TileResult
import com.dreamspace.calculator.domain.calc.TileSurface
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState

enum class TileMode { FLOOR, WALL }

class TilePreset(val label: String, val w: String, val h: String)

val TILE_PRESETS = listOf(
    TilePreset("1 x 1 ft", "1", "1"),
    TilePreset("1 x 2 ft", "1", "2"),
    TilePreset("2 x 2 ft", "2", "2"),
    TilePreset("2 x 4 ft", "2", "4"),
)
const val CUSTOM_TILE = "Custom"

class TileViewModel : ViewModel() {
    val form = FormState()
    val surfaces = form.list("surface")
    val openings = form.list("opening", 0)
    var mode by mutableStateOf(TileMode.FLOOR)
    var basis by mutableStateOf(PriceBasis.PER_SQM)
    var result by mutableStateOf<TileResult?>(null)
    var preview by mutableStateOf<SurfaceLayout?>(null)
    var message by mutableStateOf<String?>(null)
    private var modeSet = false

    init {
        form.values["wastage"] = "10"
        form.units["tile.w"] = LengthUnit.FEET
        form.units["tile.h"] = LengthUnit.FEET
        form.onEdited = { invalidate() }
    }

    fun invalidate() { result = null; preview = null; message = null }
    fun initMode(m: TileMode) { if (!modeSet) { modeSet = true; mode = m } }
    fun setBasis(b: PriceBasis) { basis = b; invalidate() }

    fun currentPreset(): String = TILE_PRESETS.firstOrNull { p ->
        form.getText("tile.w") == p.w && form.getText("tile.h") == p.h &&
            form.unit("tile.w") == LengthUnit.FEET && form.unit("tile.h") == LengthUnit.FEET
    }?.label ?: CUSTOM_TILE

    fun applyPreset(label: String) {
        val p = TILE_PRESETS.firstOrNull { it.label == label } ?: return
        form.units["tile.w"] = LengthUnit.FEET; form.units["tile.h"] = LengthUnit.FEET
        form.setText("tile.w", p.w); form.setText("tile.h", p.h)
    }

    fun calculate() {
        val r = FormReader(form)
        val floor = mode == TileMode.FLOOR
        val sizes = r.pairs(surfaces, "surface", if (floor) "Room length" else "Wall width", if (floor) "Room width" else "Wall height")
        val ops = if (floor) emptyList() else r.pairs(openings, "opening", "Opening width", "Opening height")
        val tw = r.length("tile.w", "Tile width")
        val th = r.length("tile.h", "Tile length")
        val waste = r.percent("wastage", "Wastage")
        val perBox = r.optCount("perbox", "Pieces per box")
        val price = r.optDecimal("price", "Price")
        if (r.failed || tw == null || th == null || waste == null) {
            message = "Check the highlighted fields."; result = null; preview = null; return
        }
        val name = if (floor) "Room" else "Wall"
        val input = TileInput(
            surfaces = sizes.mapIndexed { i, s -> TileSurface("$name ${i + 1}", s.first, s.second) },
            openings = ops.map { Dim(it.first.mm, it.second.mm) },
            tile = Dim(tw.mm, th.mm),
            wastagePercent = waste,
            piecesPerBox = perBox,
            basis = basis,
            price = price,
        )
        when (val res = TileCalculator.calculate(input)) {
            is Parsed.Ok -> {
                result = res.value; message = null
                val first = sizes.first()
                preview = PanelLayoutEngine.previewLayout(Surface("$name 1", first.first.mm, first.second.mm), tw.mm, th.mm)
            }
            is Parsed.Err -> { message = res.message; result = null; preview = null }
        }
    }
}
