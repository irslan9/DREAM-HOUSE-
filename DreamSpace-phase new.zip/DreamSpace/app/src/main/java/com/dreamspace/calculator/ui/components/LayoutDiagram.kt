package com.dreamspace.calculator.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.dreamspace.calculator.domain.calc.CellKind
import com.dreamspace.calculator.domain.calc.SurfaceLayout

/** Draws a wall/floor with its panel or tile grid. Floor level is at the bottom. */
@Composable
fun LayoutDiagram(layout: SurfaceLayout, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val fullColor = cs.primaryContainer
    val cutColor = cs.secondary.copy(alpha = 0.5f)
    val lineColor = cs.outline
    val openingColor = cs.onSurface
    val w = layout.surface.width.toFloat()
    val h = layout.surface.height.toFloat()
    val aspect = (w / h).coerceIn(0.5f, 3f)
    val detailed = layout.cells.size <= 3000

    Canvas(modifier.fillMaxWidth().aspectRatio(aspect)) {
        val scale = minOf(size.width / w, size.height / h)
        val ox = (size.width - w * scale) / 2f
        val oy = (size.height - h * scale) / 2f
        fun topLeft(x: Float, y: Float, ch: Float) = Offset(ox + x * scale, oy + (h - y - ch) * scale)

        drawRect(color = fullColor.copy(alpha = 0.35f), topLeft = topLeft(0f, 0f, h), size = Size(w * scale, h * scale))
        if (detailed) {
            for (c in layout.cells) {
                val x = c.x.toFloat(); val y = c.y.toFloat(); val cw = c.w.toFloat(); val ch = c.h.toFloat()
                val tl = topLeft(x, y, ch)
                val sz = Size(cw * scale, ch * scale)
                when (c.kind) {
                    CellKind.FULL -> drawRect(color = fullColor, topLeft = tl, size = sz)
                    CellKind.CUT -> drawRect(color = cutColor, topLeft = tl, size = sz)
                    CellKind.SKIPPED -> Unit
                }
                drawRect(color = lineColor, topLeft = tl, size = sz, style = Stroke(width = 1f))
            }
        }
        for (o in layout.surface.openings) {
            if (!o.positioned) continue
            val tl = topLeft(o.fromLeft!!.toFloat(), o.fromFloor!!.toFloat(), o.height.toFloat())
            val sz = Size(o.width.toFloat() * scale, o.height.toFloat() * scale)
            drawRect(color = openingColor.copy(alpha = 0.12f), topLeft = tl, size = sz)
            drawRect(color = openingColor, topLeft = tl, size = sz, style = Stroke(width = 4f))
        }
        drawRect(color = openingColor, topLeft = topLeft(0f, 0f, h), size = Size(w * scale, h * scale), style = Stroke(width = 3f))
    }
}

@Composable
fun DiagramLegend() {
    val cs = MaterialTheme.colorScheme
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
        LegendItem(cs.primaryContainer, "Full piece")
        LegendItem(cs.secondary.copy(alpha = 0.5f), "Cut piece")
        LegendItem(Color.Transparent, "Opening", outline = cs.onSurface)
    }
}

@Composable
private fun LegendItem(color: Color, text: String, outline: Color? = null) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).background(color)) {
            if (outline != null) Box(Modifier.size(14.dp).background(outline.copy(alpha = 0.2f)))
        }
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}
