package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal

enum class PriceBasis(val label: String) {
    PER_SQM("per m\u00B2"),
    PER_SQFT("per ft\u00B2"),
    PER_PIECE("per piece"),
    PER_BOX("per box"),
}

object Pricing {
    fun pieceCost(basis: PriceBasis, price: BigDecimal, pieces: Long, pieceArea: Area, boxes: Long?): BigDecimal? =
        when (basis) {
            PriceBasis.PER_SQM -> pieceArea.sqMeters.multiply(pieces.toBd()).multiply(price)
            PriceBasis.PER_SQFT -> pieceArea.sqFeet.multiply(pieces.toBd()).multiply(price)
            PriceBasis.PER_PIECE -> pieces.toBd().multiply(price)
            PriceBasis.PER_BOX -> boxes?.toBd()?.multiply(price)
        }

    fun areaCost(basis: PriceBasis, price: BigDecimal, area: Area): BigDecimal? = when (basis) {
        PriceBasis.PER_SQM -> area.sqMeters.multiply(price)
        PriceBasis.PER_SQFT -> area.sqFeet.multiply(price)
        else -> null
    }
}

enum class CostUnit(val label: String, val isArea: Boolean) {
    SQ_FT("ft\u00B2", true),
    SQ_M("m\u00B2", true),
    PANEL("panel", false),
    TILE("tile", false),
    BOX("box", false),
}

data class CostLine(
    val name: String,
    val qty: BigDecimal,
    val qtyUnit: CostUnit,
    val price: BigDecimal,
    val priceUnit: CostUnit,
)

data class CostResult(
    val lineTotals: List<BigDecimal>,
    val subtotal: BigDecimal,
    val wastageCost: BigDecimal,
    val labour: BigDecimal,
    val installation: BigDecimal,
    val additional: BigDecimal,
    val grandTotal: BigDecimal,
)

object CostEstimator {
    fun lineTotal(l: CostLine): Parsed<BigDecimal> {
        val qty: BigDecimal = when {
            l.qtyUnit == l.priceUnit -> l.qty
            l.qtyUnit.isArea && l.priceUnit.isArea ->
                if (l.qtyUnit == CostUnit.SQ_FT) Area.fromSquareFeet(l.qty).sqMeters
                else Area.fromSquareMeters(l.qty).sqFeet
            else -> return Parsed.Err("${l.name}: quantity is in ${l.qtyUnit.label} but the price is per ${l.priceUnit.label}.")
        }
        return Parsed.Ok(qty.multiply(l.price))
    }

    fun estimate(
        lines: List<CostLine>,
        wastagePercent: BigDecimal,
        labour: BigDecimal,
        installation: BigDecimal,
        additional: BigDecimal,
    ): Parsed<CostResult> {
        if (lines.isEmpty()) return Parsed.Err("Add at least one material line.")
        val totals = ArrayList<BigDecimal>()
        for (l in lines) {
            when (val r = lineTotal(l)) {
                is Parsed.Ok -> totals.add(r.value)
                is Parsed.Err -> return r
            }
        }
        val subtotal = totals.fold(BigDecimal.ZERO) { a, b -> a.add(b) }
        val wastage = subtotal.multiply(wastagePercent).divMc(BigDecimal(100))
        val grand = subtotal.add(wastage).add(labour).add(installation).add(additional)
        return Parsed.Ok(CostResult(totals, subtotal, wastage, labour, installation, additional, grand))
    }
}
