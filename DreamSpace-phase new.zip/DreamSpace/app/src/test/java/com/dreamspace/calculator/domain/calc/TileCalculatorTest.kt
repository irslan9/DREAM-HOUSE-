package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TileCalculatorTest {
    private fun ft(v: String) = Length.of(BigDecimal(v), LengthUnit.FEET)
    private fun dimFt(w: String, h: String) = Dim(ft(w).mm, ft(h).mm)

    private fun run(
        surfaces: List<TileSurface>,
        tile: Dim,
        waste: String,
        openings: List<Dim> = emptyList(),
        perBox: Long? = null,
        basis: PriceBasis = PriceBasis.PER_PIECE,
        price: String? = null,
    ): TileResult {
        val r = TileCalculator.calculate(
            TileInput(surfaces, openings, tile, BigDecimal(waste), perBox, basis, price?.let { BigDecimal(it) }),
        )
        assertTrue("$r", r is Parsed.Ok)
        return (r as Parsed.Ok).value
    }

    private val room10x12 = listOf(TileSurface("Room", ft("10"), ft("12")))

    @Test fun floorTwoByTwoTenPercent() {
        val r = run(room10x12, dimFt("2", "2"), "10")
        assertEquals(0, BigDecimal("30").compareTo(r.theoreticalExact))
        assertEquals(30L, r.theoretical)
        assertEquals(33L, r.practical)
        assertEquals(3L, r.wastageTiles)
    }

    @Test fun wastageFivetenFifteen() {
        assertEquals(32L, run(room10x12, dimFt("2", "2"), "5").practical)
        assertEquals(33L, run(room10x12, dimFt("2", "2"), "10").practical)
        assertEquals(35L, run(room10x12, dimFt("2", "2"), "15").practical)
    }

    @Test fun partialTilesRoundUp() {
        val room = listOf(TileSurface("Room", ft("10"), ft("11")))
        val r = run(room, dimFt("2", "2"), "10")
        assertEquals(28L, r.theoretical)   // 27.5 -> 28
        assertEquals(31L, r.practical)     // 30.25 -> 31
    }

    @Test fun wallWithDoorAndWindow() {
        val wall = listOf(TileSurface("Wall", ft("10"), ft("10")))
        val r = run(wall, dimFt("1", "1"), "10", openings = listOf(dimFt("3", "7"), dimFt("4", "3")))
        assertEquals(0, BigDecimal("67").compareTo(r.net.sqFeet))
        assertEquals(67L, r.theoretical)
        assertEquals(74L, r.practical)
    }

    @Test fun multipleRoomsAreSummed() {
        val rooms = listOf(TileSurface("A", ft("10"), ft("12")), TileSurface("B", ft("10"), ft("12")))
        assertEquals(60L, run(rooms, dimFt("2", "2"), "0").theoretical)
    }

    @Test fun boxesAndCost() {
        val r = run(room10x12, dimFt("2", "2"), "10", perBox = 4, basis = PriceBasis.PER_BOX, price = "5000")
        assertEquals(9L, r.boxes)
        assertEquals(36L, r.purchasedTiles)
        assertEquals(0, BigDecimal("45000").compareTo(r.cost))
    }

    @Test fun costPerPieceAndPerSquareMeter() {
        val perPiece = run(room10x12, dimFt("2", "2"), "10", basis = PriceBasis.PER_PIECE, price = "100")
        assertEquals(0, BigDecimal("3300").compareTo(perPiece.cost))
        val perSqm = run(room10x12, dimFt("2", "2"), "0", basis = PriceBasis.PER_SQM, price = "1000")
        // 30 tiles x 0.37161216 m2 x 1000
        assertEquals(0, BigDecimal("11148.3648").compareTo(perSqm.cost))
    }

    @Test fun noPriceMeansNoCost() {
        assertNull(run(room10x12, dimFt("2", "2"), "10").cost)
    }

    @Test fun openingsLargerThanWallAreRejected() {
        val wall = listOf(TileSurface("Wall", ft("5"), ft("5")))
        val r = TileCalculator.calculate(
            TileInput(wall, listOf(dimFt("6", "6")), dimFt("1", "1"), BigDecimal.TEN, null, PriceBasis.PER_PIECE, null),
        )
        assertTrue(r is Parsed.Err)
    }

    @Test fun priceByBoxNeedsPiecesPerBox() {
        val r = TileCalculator.calculate(
            TileInput(room10x12, emptyList(), dimFt("2", "2"), BigDecimal.TEN, null, PriceBasis.PER_BOX, BigDecimal(100)),
        )
        assertTrue(r is Parsed.Err)
    }
}
