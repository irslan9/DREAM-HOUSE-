package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Area
import com.dreamspace.calculator.domain.measure.AreaUnit
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeCalculatorsTest {
    private fun <T> ok(r: Parsed<T>): T {
        assertTrue("$r", r is Parsed.Ok)
        @Suppress("UNCHECKED_CAST")
        return (r as Parsed.Ok<T>).value
    }
    private fun mm(v: Int) = Length(BigDecimal(v))
    private fun bd(v: String) = BigDecimal(v)
    private fun same(expected: String, actual: BigDecimal?) =
        assertEquals("expected $expected got $actual", 0, BigDecimal(expected).compareTo(actual))

    @Test fun staircaseAreas() {
        val r = ok(StairCalculator.calculate(10, mm(250), mm(175), mm(1000), BigDecimal.ZERO, null, PriceBasis.PER_SQM, null))
        same("0.25", r.treadEach.sqMeters)
        same("2.5", r.treadTotal.sqMeters)
        same("1.75", r.riserTotal.sqMeters)
        same("4.25", r.total.sqMeters)
    }

    @Test fun staircaseSlabsAndCost() {
        // 10 treads (1000x250) + 10 risers (1000x175) from 2000x1000 slabs, rotation allowed
        val r = ok(StairCalculator.calculate(10, mm(250), mm(175), mm(1000), bd("10"), Dim(bd("2000"), bd("1000")), PriceBasis.PER_PIECE, bd("1000")))
        assertTrue(r.slabsLayout!! >= 3)
        assertTrue(r.slabsPractical!! >= r.slabsLayout!!)
        same((r.slabsPractical!! * 1000).toString(), r.cost)
    }

    @Test fun staircaseSlabTooSmall() {
        val r = StairCalculator.calculate(5, mm(250), mm(175), mm(1000), BigDecimal.ZERO, Dim(bd("500"), bd("500")), PriceBasis.PER_PIECE, null)
        assertTrue(r is Parsed.Err)
    }

    @Test fun paintLitres() {
        val net = Area.fromSquareFeet(bd("100"))
        val r = ok(PaintCalculator.calculate(net, 2, bd("100"), AreaUnit.SQUARE_FEET, bd("10"), bd("4"), bd("800")))
        same("2", r.litresExact)
        same("2.2", r.litresPractical)
        assertEquals(1L, r.cans)
        same("4", r.purchasedLitres)
        same("3200", r.cost)
    }

    @Test fun paintCoverageInSquareMeters() {
        val net = Area.fromSquareMeters(bd("20"))
        val r = ok(PaintCalculator.calculate(net, 2, bd("10"), AreaUnit.SQUARE_METERS, BigDecimal.ZERO, null, null))
        same("4", r.litresExact)
    }

    @Test fun wallpaperWithAndWithoutPatternRepeat() {
        val wall = listOf(Dim(bd("3000"), bd("2700")))
        val plain = ok(WallpaperCalculator.calculate(wall, emptyList(), bd("530"), bd("9000"), null, BigDecimal.ZERO, BigDecimal.ZERO, null))
        assertEquals(6L, plain.strips)
        assertEquals(3L, plain.dropsPerRoll)
        assertEquals(2L, plain.rollsTheoretical)
        val repeat = ok(WallpaperCalculator.calculate(wall, emptyList(), bd("530"), bd("9000"), bd("2000"), BigDecimal.ZERO, BigDecimal.ZERO, null))
        same("4000", repeat.stripLength)
        assertEquals(2L, repeat.dropsPerRoll)
        assertEquals(3L, repeat.rollsTheoretical)
    }

    @Test fun wallpaperWastageAndCost() {
        val wall = listOf(Dim(bd("3000"), bd("2700")))
        val r = ok(WallpaperCalculator.calculate(wall, emptyList(), bd("530"), bd("9000"), null, BigDecimal.ZERO, bd("10"), bd("2500")))
        assertEquals(3L, r.rollsPractical)   // 2 x 1.1 = 2.2 -> 3
        same("7500", r.cost)
    }

    @Test fun wallpaperWallTallerThanRoll() {
        val r = WallpaperCalculator.calculate(listOf(Dim(bd("3000"), bd("5000"))), emptyList(), bd("530"), bd("4000"), null, BigDecimal.ZERO, BigDecimal.ZERO, null)
        assertTrue(r is Parsed.Err)
    }

    @Test fun costEstimateWithUnitConversion() {
        val lines = listOf(
            CostLine("PVC", bd("10"), CostUnit.SQ_M, bd("1500"), CostUnit.SQ_M),
            CostLine("Tiles", bd("100"), CostUnit.SQ_FT, bd("200"), CostUnit.SQ_FT),
        )
        val r = ok(CostEstimator.estimate(lines, bd("10"), bd("5000"), bd("2000"), bd("1000")))
        same("35000", r.subtotal)
        same("3500", r.wastageCost)
        same("46500", r.grandTotal)
    }

    @Test fun costAreaUnitsConvert() {
        val l = CostLine("Tiles", bd("100"), CostUnit.SQ_FT, bd("1000"), CostUnit.SQ_M)
        same("9290.304", ok(CostEstimator.lineTotal(l)))
    }

    @Test fun costMismatchedUnitsAreRejected() {
        val l = CostLine("Panels", bd("10"), CostUnit.PANEL, bd("500"), CostUnit.TILE)
        assertTrue(CostEstimator.lineTotal(l) is Parsed.Err)
        assertTrue(CostEstimator.estimate(emptyList(), BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO) is Parsed.Err)
    }

    @Test fun lengthHelperStillExact() {
        same("3048", Length.of(bd("10"), LengthUnit.FEET).mm)
    }
}
