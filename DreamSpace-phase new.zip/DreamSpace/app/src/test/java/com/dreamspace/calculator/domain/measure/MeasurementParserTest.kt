package com.dreamspace.calculator.domain.measure

import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MeasurementParserTest {
    private fun mm(text: String, unit: LengthUnit = LengthUnit.FEET_INCHES): BigDecimal {
        val r = MeasurementParser.parse(text, unit)
        assertTrue("expected success for '$text' but got $r", r is Parsed.Ok)
        return (r as Parsed.Ok).value.mm
    }

    private fun assertMm(expected: String, actual: BigDecimal) =
        assertEquals("expected $expected got ${actual.toPlainString()}", 0, BigDecimal(expected).compareTo(actual))

    private fun assertError(text: String, unit: LengthUnit = LengthUnit.FEET_INCHES) =
        assertTrue("expected error for '$text'", MeasurementParser.parse(text, unit) is Parsed.Err)

    @Test fun mixedFeetAndInches() {
        assertMm("1701.8", mm("5 ft 7 in"))
        assertMm("3200.4", mm("10 ft 6 in"))
        assertMm("3200.4", mm("10ft 6in"))
        assertMm("1701.8", mm("5'7\""))
        assertMm("1701.8", mm("5\u20327\u2033"))
        assertMm("1701.8", mm("5-7"))
        assertMm("1701.8", mm("5 7"))
        assertMm("1524", mm("5 ft"))
        assertMm("1816.1", mm("5 ft 11.5 in"))
    }

    @Test fun metricAndInchUnits() {
        assertMm("280", mm("280 mm"))
        assertMm("300", mm("30 cm"))
        assertMm("2900", mm("2.9 m"))
        assertMm("254", mm("10 in"))
        assertMm("254", mm("10\""))
        assertMm("254", mm("10 inches"))
    }

    @Test fun plainNumbersUseSelectedUnit() {
        assertMm("1676.4", mm("5.5", LengthUnit.FEET))
        assertMm("1524", mm("5", LengthUnit.FEET_INCHES))
        assertMm("914.4", mm("36", LengthUnit.INCHES))
        assertMm("2900", mm("2900", LengthUnit.MILLIMETERS))
        assertMm("3500", mm("3.5", LengthUnit.METERS))
        assertMm("2800", mm("280", LengthUnit.CENTIMETERS))
        assertMm("152.4", mm(".5", LengthUnit.FEET))
    }

    @Test fun invalidInputReturnsErrorsInsteadOfCrashing() {
        assertError("")
        assertError("   ")
        assertError("abc")
        assertError("-5")
        assertError("0")
        assertError("5 ft 12 in")
        assertError("5 ft 70 in")
        assertError("2000 m")
        assertError("5-7", LengthUnit.METERS)
        assertError("1.2.3")
    }

    @Test fun zeroAllowedWhenRequested() {
        val r = MeasurementParser.parse("0", LengthUnit.FEET, allowZero = true)
        assertTrue(r is Parsed.Ok)
    }

    @Test fun decimalParsing() {
        assertTrue(MeasurementParser.parseDecimal("10", "Wastage") is Parsed.Ok)
        assertTrue(MeasurementParser.parseDecimal("", "Wastage") is Parsed.Err)
        assertTrue(MeasurementParser.parseDecimal("-1", "Wastage") is Parsed.Err)
        assertTrue(MeasurementParser.parseDecimal("0", "Price") is Parsed.Err)
        assertTrue(MeasurementParser.parseDecimal("0", "Wastage", allowZero = true) is Parsed.Ok)
    }
}
