package com.dreamspace.calculator.domain.calc

import com.dreamspace.calculator.domain.measure.Parsed
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PanelLayoutTest {
    private fun bd(v: Int) = BigDecimal(v)
    private fun d(w: Int, h: Int) = Dim(bd(w), bd(h))
    private fun wall(w: Int, h: Int, ops: List<Opening> = emptyList()) = Surface("Wall", bd(w), bd(h), ops)

    private fun estimate(
        surfaces: List<Surface>,
        panel: Dim,
        mode: OrientationMode = OrientationMode.VERTICAL,
        rotate: Boolean = false,
        waste: String = "0",
    ): PanelEstimate {
        val r = PanelLayoutEngine.estimate(surfaces, panel, mode, rotate, BigDecimal(waste), null, PriceBasis.PER_PIECE)
        assertTrue("$r", r is Parsed.Ok)
        return (r as Parsed.Ok).value
    }

    @Test fun exactFitNeedsNoCuts() {
        val e = estimate(listOf(wall(3000, 2900)), d(300, 2900))
        assertEquals(10L, e.chosen.fullPanels)
        assertEquals(0L, e.chosen.cutPieces)
        assertEquals(10L, e.chosen.panelsRequired)
    }

    @Test fun narrowStripNeedsOneExtraPanel() {
        val e = estimate(listOf(wall(3100, 2900)), d(300, 2900))
        assertEquals(11L, e.chosen.layouts[0].cols)
        assertEquals(10L, e.chosen.fullPanels)
        assertEquals(1L, e.chosen.cutPieces)
        assertEquals(11L, e.chosen.panelsRequired)
    }

    @Test fun shortTopRowPiecesShareOnePanel() {
        val e = estimate(listOf(wall(3000, 3000)), d(300, 2900))
        assertEquals(2L, e.chosen.layouts[0].rows)
        assertEquals(10L, e.chosen.cutPieces)
        assertEquals(1L, e.chosen.panelsFromCuts)
        assertEquals(11L, e.chosen.panelsRequired)
    }

    @Test fun layoutCanNeedMoreThanAreaAlone() {
        val e = estimate(listOf(wall(3000, 2400)), d(300, 2800))
        assertEquals(9L, e.theoreticalByArea)
        assertEquals(10L, e.chosen.panelsRequired)
    }

    @Test fun autoPicksFewerPanels() {
        val e = estimate(listOf(wall(3000, 2400)), d(300, 2800), mode = OrientationMode.AUTO)
        assertEquals(2, e.compared.size)
        assertEquals(Orientation.HORIZONTAL, e.chosen.orientation)
        assertEquals(9L, e.chosen.panelsRequired)
        val vertical = e.compared.first { it.orientation == Orientation.VERTICAL }
        assertEquals(10L, vertical.panelsRequired)
    }

    @Test fun doorDoesNotAutomaticallyReducePanels() {
        val door = Opening(bd(900), bd(2100), bd(300), BigDecimal.ZERO)
        val e = estimate(listOf(wall(3000, 2900, listOf(door))), d(300, 2900))
        assertEquals(10L, e.chosen.panelsRequired)
        assertEquals(0L, e.chosen.panelsSavedByOpenings)
        // but the area deduction is still reported
        assertEquals(0, BigDecimal("1890000").compareTo(e.openings.sqMm))
    }

    @Test fun positionedDoorSavesWholePiecesOnlyWhenCellsAreFullyCovered() {
        val door = Opening(bd(900), bd(2100), bd(300), BigDecimal.ZERO)
        val e = estimate(listOf(wall(3000, 2800, listOf(door))), d(300, 700))
        assertEquals(9L, e.chosen.skippedCells)
        assertEquals(31L, e.chosen.panelsRequired)
        assertEquals(9L, e.chosen.panelsSavedByOpenings)
    }

    @Test fun unpositionedOpeningOnlyDeductsArea() {
        val window = Opening(bd(900), bd(1200), null, null)
        val e = estimate(listOf(wall(3000, 2800, listOf(window))), d(300, 700))
        assertEquals(40L, e.chosen.panelsRequired)
        assertEquals(0, BigDecimal(3000L * 2800 - 900 * 1200).compareTo(e.net.sqMm))
    }

    @Test fun wastageAllowanceRoundsUp() {
        val base = estimate(listOf(wall(2700, 2900)), d(300, 2900), waste = "0")
        assertEquals(9L, base.practicalPanels)
        assertEquals(10L, estimate(listOf(wall(2700, 2900)), d(300, 2900), waste = "10").practicalPanels) // 9.9
        assertEquals(10L, estimate(listOf(wall(2700, 2900)), d(300, 2900), waste = "5").practicalPanels)  // 9.45
        assertEquals(11L, estimate(listOf(wall(2700, 2900)), d(300, 2900), waste = "15").practicalPanels) // 10.35
    }

    @Test fun customMarketSizesInInches() {
        // 10 in x 10 ft panel on a 10 ft x 10 ft wall: 254 mm x 3048 mm
        val e = estimate(listOf(wall(3048, 3048)), d(254, 3048))
        assertEquals(12L, e.chosen.layouts[0].cols)  // 3048 / 254 = 12
        assertEquals(12L, e.chosen.panelsRequired)
    }

    @Test fun multipleWallsShareOffcuts() {
        val e = estimate(listOf(wall(3000, 3000), wall(3000, 3000)), d(300, 2900))
        assertEquals(20L, e.chosen.fullPanels)
        assertEquals(20L, e.chosen.cutPieces)
        assertEquals(1L, e.chosen.panelsFromCuts)
    }

    @Test fun invalidOpeningIsRejected() {
        val big = Opening(bd(5000), bd(1000), null, null)
        val r = PanelLayoutEngine.estimate(
            listOf(wall(3000, 2900, listOf(big))), d(300, 2900), OrientationMode.VERTICAL, false,
            BigDecimal.ZERO, null, PriceBasis.PER_PIECE,
        )
        assertTrue(r is Parsed.Err)
    }

    @Test fun packerRespectsRotation() {
        assertEquals(1L, Packer.pack(d(1000, 500), listOf(d(500, 1000)), true)!!.stockUsed)
        assertNull(Packer.pack(d(1000, 500), listOf(d(500, 1000)), false))
    }

    @Test fun packerStacksSmallPieces() {
        val pieces = List(10) { d(300, 100) }
        assertEquals(1L, Packer.pack(d(300, 2900), pieces, false)!!.stockUsed)
        assertNotNull(Packer.pack(d(300, 2900), pieces, false)!!.freeRects)
    }
}
