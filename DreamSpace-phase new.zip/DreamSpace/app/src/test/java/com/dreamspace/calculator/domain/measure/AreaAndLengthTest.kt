package com.dreamspace.calculator.domain.measure

import java.math.BigDecimal
import java.math.RoundingMode
import org.junit.Assert.assertEquals
import org.junit.Test

class AreaAndLengthTest {
    private fun assertBd(expected: String, actual: BigDecimal) =
        assertEquals("expected $expected got ${actual.toPlainString()}", 0, BigDecimal(expected).compareTo(actual))

    @Test fun lengthConversions() {
        val foot = Length(BigDecimal("304.8"))
        assertBd("1", foot.feet)
        assertBd("12", foot.inches)
        assertBd("0.3048", foot.meters)
        assertBd("30.48", foot.cm)
        assertBd("1", Length(BigDecimal("25.4")).inches)
        assertBd("1", Length(BigDecimal("1000")).meters)
    }

    @Test fun oneSquareFootIsExactlyDefinedValue() {
        val a = Area.of(Length.of(BigDecimal.ONE, LengthUnit.FEET), Length.of(BigDecimal.ONE, LengthUnit.FEET))
        assertBd("0.09290304", a.sqMeters)
        assertBd("1", a.sqFeet)
    }

    @Test fun roomAreaTenByTwelveFeet() {
        val a = Area.of(Length.of(BigDecimal(10), LengthUnit.FEET), Length.of(BigDecimal(12), LengthUnit.FEET))
        assertBd("120", a.sqFeet)
        assertBd("11.1483648", a.sqMeters)
    }

    @Test fun squareMetersRoundTrip() {
        assertBd("120", Area.fromSquareMeters(BigDecimal("11.1483648")).sqFeet)
        assertBd("11.1483648", Area.fromSquareFeet(BigDecimal(120)).sqMeters)
    }

    @Test fun mixedFeetInchesArea() {
        // 5 ft 7 in x 10 ft 6 in = 1701.8 mm x 3200.4 mm
        val a = Area.of(Length.ofFeetInches(BigDecimal(5), BigDecimal(7)), Length.ofFeetInches(BigDecimal(10), BigDecimal(6)))
        assertBd("5446440.72", a.sqMm)
        assertBd("58.625", a.sqFeet.setScale(3, RoundingMode.HALF_UP))
    }

    @Test fun feetInchesDisplay() {
        assertEquals("5 ft 7 in", Length(BigDecimal("1701.8")).displayFeetInches())
        assertEquals("10 ft 6 in", Length(BigDecimal("3200.4")).displayFeetInches())
        assertEquals("10 ft", Length(BigDecimal("3048")).displayFeetInches())
        assertEquals("10 in", Length(BigDecimal("254")).displayFeetInches())
    }

    @Test fun displayTrimsTrailingZerosOnly() {
        assertEquals("120", BigDecimal("120.000").display(2))
        assertEquals("1.5", BigDecimal("1.50").display(2))
        assertEquals("0", BigDecimal.ZERO.display(2))
        assertEquals("0.33", BigDecimal("0.3333333").display(2))
    }
}
