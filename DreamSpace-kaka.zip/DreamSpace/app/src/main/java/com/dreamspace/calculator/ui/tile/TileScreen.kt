package com.dreamspace.calculator.ui.tile

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dreamspace.calculator.domain.calc.PriceBasis
import com.dreamspace.calculator.domain.calc.TileResult
import com.dreamspace.calculator.domain.calc.pkr
import com.dreamspace.calculator.domain.measure.display
import com.dreamspace.calculator.ui.components.DiagramLegend
import com.dreamspace.calculator.ui.components.LayoutDiagram
import com.dreamspace.calculator.ui.components.ResultCard
import com.dreamspace.calculator.ui.components.ResultRow
import com.dreamspace.calculator.ui.components.ScreenScaffold
import com.dreamspace.calculator.ui.components.show
import com.dreamspace.calculator.ui.form.AddRowButton
import com.dreamspace.calculator.ui.form.CalculateButton
import com.dreamspace.calculator.ui.form.ChipRow
import com.dreamspace.calculator.ui.form.ErrorNote
import com.dreamspace.calculator.ui.form.FormMeasure
import com.dreamspace.calculator.ui.form.FormNumber
import com.dreamspace.calculator.ui.form.HintText
import com.dreamspace.calculator.ui.form.RowHeader
import com.dreamspace.calculator.ui.form.SectionTitle
import com.dreamspace.calculator.ui.form.SizeRows

@Composable
fun TileScreen(mode: TileMode, onBack: () -> Unit, vm: TileViewModel = viewModel()) {
    LaunchedEffect(mode) { vm.initMode(mode) }
    val floor = vm.mode == TileMode.FLOOR
    val form = vm.form

    ScreenScaffold(if (floor) "Floor Tile Calculator" else "Wall Tile Calculator", onBack) {
        SectionTitle(if (floor) "Rooms and floor areas" else "Walls")
        SizeRows(
            form, vm.surfaces, "surface", if (floor) "Room" else "Wall",
            if (floor) "Room length" else "Wall width",
            if (floor) "Room width" else "Wall height",
            onChanged = vm::invalidate,
        )

        if (!floor) {
            SectionTitle("Doors and windows")
            HintText("Their area is deducted from the wall area.")
            vm.openings.ids.forEachIndexed { i, id ->
                key(id) {
                    RowHeader("Opening ${i + 1}", { vm.openings.remove(id); vm.invalidate() })
                    FormMeasure(form, "opening$id.a", "Opening width")
                    FormMeasure(form, "opening$id.b", "Opening height")
                }
            }
            AddRowButton("Add door or window") { vm.openings.add(); vm.invalidate() }
        }

        SectionTitle("Tile size")
        ChipRow(TILE_PRESETS.map { it.label } + CUSTOM_TILE, vm.currentPreset(), { it }) { vm.applyPreset(it) }
        FormMeasure(form, "tile.w", "Tile width")
        FormMeasure(form, "tile.h", "Tile length")

        SectionTitle("Wastage, boxes and price")
        FormNumber(form, "wastage", "Wastage (%)", hint = "Try 5, 10 or 15")
        FormNumber(form, "perbox", "Tile pieces per box (optional)")
        ChipRow(PriceBasis.entries.toList(), vm.basis, { it.label }) { vm.changeBasis(it) }
        FormNumber(form, "price", "Price in PKR (optional)", hint = "Price ${vm.basis.label}")

        CalculateButton(vm::calculate)
        ErrorNote(vm.message)
        vm.result?.let { TileResultCards(it) }
        vm.preview?.let { layout ->
            SectionTitle("Layout preview")
            HintText("First ${if (floor) "room" else "wall"} with your tile size.")
            LayoutDiagram(layout)
            DiagramLegend()
        }
    }
}

@Composable
private fun TileResultCards(r: TileResult) {
    ResultCard("Areas", listOf(
        ResultRow("Gross area", r.gross.show()),
        ResultRow("Openings deducted", r.deduction.show()),
        ResultRow("Net area", r.net.show()),
        ResultRow("One tile", r.tileArea.show()),
    ))
    val rows = ArrayList<ResultRow>()
    rows.add(ResultRow("Theoretical (exact)", r.theoreticalExact.display(2)))
    rows.add(ResultRow("Theoretical (whole tiles)", "${r.theoretical}"))
    rows.add(ResultRow("Wastage (${r.wastagePercent.display(2)}%)", "+${r.wastageTiles}"))
    rows.add(ResultRow("Practical quantity", "${r.practical}"))
    if (r.boxes != null) {
        rows.add(ResultRow("Boxes to buy", "${r.boxes}"))
        rows.add(ResultRow("Tiles in those boxes", "${r.purchasedTiles}"))
    }
    rows.add(ResultRow("Estimated cost", r.cost?.pkr() ?: "Enter a price"))
    ResultCard("Tiles", rows)
    Text(
        "Net area divided by one tile gives ${r.theoreticalExact.display(2)} tiles. " +
            "That rounds up to ${r.theoretical}. With ${r.wastagePercent.display(2)}% wastage the exact " +
            "figure is rounded up again to ${r.practical}.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
    )
}
