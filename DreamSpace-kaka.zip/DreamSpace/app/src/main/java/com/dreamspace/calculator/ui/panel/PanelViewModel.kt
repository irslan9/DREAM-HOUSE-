package com.dreamspace.calculator.ui.panel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.dreamspace.calculator.domain.calc.Dim
import com.dreamspace.calculator.domain.calc.Opening
import com.dreamspace.calculator.domain.calc.OrientationMode
import com.dreamspace.calculator.domain.calc.PanelEstimate
import com.dreamspace.calculator.domain.calc.PanelLayoutEngine
import com.dreamspace.calculator.domain.calc.PriceBasis
import com.dreamspace.calculator.domain.calc.Surface
import com.dreamspace.calculator.domain.calc.plain
import com.dreamspace.calculator.domain.measure.Length
import com.dreamspace.calculator.domain.measure.LengthUnit
import com.dreamspace.calculator.domain.measure.Parsed
import com.dreamspace.calculator.ui.form.FormReader
import com.dreamspace.calculator.ui.form.FormState
import com.dreamspace.calculator.ui.form.RowList
import java.math.BigDecimal

enum class PanelType(val label: String, val rotate: Boolean) {
    PVC("PVC", false),
    WPC("WPC", false),
    FLUTED("Fluted", false),
    CHARCOAL("Charcoal", false),
    MARBLE_SHEET("Marble sheet", true),
    WOODEN("Wooden decorative", false),
    MARBLE_GRANITE("Marble / granite slab", true),
    CUSTOM("Custom material", false),
}

class PanelViewModel(app: Application) : AndroidViewModel(app) {
    val form = FormState()
    val walls = form.list("wall")
    private val library = PanelLibrary(app)
    val saved = mutableStateListOf<SavedPanel>()

    var type by mutableStateOf(PanelType.PVC)
    var mode by mutableStateOf(OrientationMode.AUTO)
    var allowRotate by mutableStateOf(false)
    var basis by mutableStateOf(PriceBasis.PER_PIECE)
    var estimate by mutableStateOf<PanelEstimate?>(null)
    var message by mutableStateOf<String?>(null)
    private var initialised = false

    init {
        form.values["wastage"] = "10"
        form.onEdited = { invalidate() }
        refreshLibrary()
    }

    fun invalidate() { estimate = null; message = null }

    fun initType(t: PanelType) { if (!initialised) { initialised = true; changeType(t) } }
    fun changeType(t: PanelType) { type = t; allowRotate = t.rotate; invalidate() }
    fun changeMode(m: OrientationMode) { mode = m; invalidate() }
    fun setRotate(v: Boolean) { allowRotate = v; invalidate() }
    fun changeBasis(b: PriceBasis) { basis = b; invalidate() }
    fun removeWall(id: Int) { walls.remove(id); invalidate() }
    fun removeOpening(list: RowList, id: Int) { list.remove(id); invalidate() }

    // ---- library ----
    private fun refreshLibrary() { saved.clear(); saved.addAll(library.all()) }

    fun usePanel(p: SavedPanel) {
        form.units["panel.w"] = LengthUnit.MILLIMETERS
        form.units["panel.h"] = LengthUnit.MILLIMETERS
        form.setText("panel.w", p.widthMm.plain())
        form.setText("panel.h", p.heightMm.plain())
    }

    fun savePanel(id: Long?, name: String, w: Length, h: Length) {
        library.upsert(SavedPanel(id ?: System.currentTimeMillis(), name, w.mm, h.mm))
        refreshLibrary()
    }

    fun deletePanel(id: Long) { library.delete(id); refreshLibrary() }

    // ---- calculation ----
    private fun readOpening(r: FormReader, p: String): Opening? {
        val w = r.length("$p.w", "Opening width")
        val h = r.length("$p.h", "Opening height")
        val window = form.flag("$p.window")
        val left = r.optLength("$p.left", "Distance from left edge")
        val floor = if (window) r.optLength("$p.floor", "Height from floor") else null
        if (window && (left == null) != (floor == null)) {
            r.error(if (left == null) "$p.left" else "$p.floor", "Enter both position fields, or leave both empty.")
        }
        if (w == null || h == null) return null
        val fromFloor: BigDecimal? = if (window) floor?.mm else if (left != null) BigDecimal.ZERO else null
        return Opening(w.mm, h.mm, left?.mm, fromFloor)
    }

    fun calculate() {
        val r = FormReader(form)
        val pw = r.length("panel.w", "Panel width")
        val ph = r.length("panel.h", "Panel height")
        val surfaces = ArrayList<Surface>()
        walls.ids.forEachIndexed { i, id ->
            val w = r.length("wall$id.w", "Wall width")
            val h = r.length("wall$id.h", "Wall height")
            val ops = form.list("wall$id.o", 0).ids.mapNotNull { oid -> readOpening(r, "wall$id.o$oid") }
            if (w != null && h != null) surfaces.add(Surface("Wall ${i + 1}", w.mm, h.mm, ops))
        }
        val waste = r.percent("wastage", "Wastage")
        val price = r.optDecimal("price", "Price")
        if (r.failed || pw == null || ph == null || waste == null) {
            message = "Check the highlighted fields."; estimate = null; return
        }
        when (val res = PanelLayoutEngine.estimate(surfaces, Dim(pw.mm, ph.mm), mode, allowRotate, waste, price, basis)) {
            is Parsed.Ok -> { estimate = res.value; message = null }
            is Parsed.Err -> { estimate = null; message = res.message }
        }
    }
}
