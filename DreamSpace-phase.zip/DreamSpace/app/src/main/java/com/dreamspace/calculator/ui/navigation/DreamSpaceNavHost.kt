package com.dreamspace.calculator.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.dreamspace.calculator.ui.components.PendingScreen
import com.dreamspace.calculator.ui.converter.ConverterScreen
import com.dreamspace.calculator.ui.dashboard.DashboardScreen

private const val DASHBOARD = "dashboard"

@Composable
fun DreamSpaceNavHost() {
    val nav = rememberNavController()
    val back: () -> Unit = { nav.popBackStack() }
    NavHost(
        navController = nav,
        startDestination = DASHBOARD,
        enterTransition = { fadeIn(tween(240)) + slideInHorizontally(tween(240)) { it / 14 } },
        exitTransition = { fadeOut(tween(160)) },
        popEnterTransition = { fadeIn(tween(240)) },
        popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(240)) { it / 14 } },
    ) {
        composable(DASHBOARD) { DashboardScreen(onOpen = { nav.navigate(it.route) }) }
        composable(Destination.UnitConverter.route) { ConverterScreen(onBack = back) }
        Destination.entries.filter { it.phase != null }.forEach { d ->
            composable(d.route) { PendingScreen(d, onBack = back) }
        }
    }
}
